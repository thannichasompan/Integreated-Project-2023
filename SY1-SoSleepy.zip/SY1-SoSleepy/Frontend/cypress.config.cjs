const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
   specPattern: "cypress/e2e/**/*.{cy,spec}.{js,jsx,ts,tsx}",
   baseUrl:"http://localhost:5173/",
   experimentalSessionAndOrigin: true
  },
});
// http://localhost:5173/
//http://intproj22.sit.kmutt.ac.th/sy1/