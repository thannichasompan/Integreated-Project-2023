<script setup>
import { ref, onMounted} from 'vue';
import { useRouter } from 'vue-router'
import { formatDate } from '../composable/formatDate'
import { userAnnouncement } from '../stores/announcerStore'
import { parseJwt } from '../composable/getToken'
import { inject } from 'vue'
const FETCH_API = import.meta.env.VITE_API
const announcementData = ref({})
const errorMessage = ref()
const router = useRouter()
const categories = ref({})
const userAnn = userAnnouncement()
const category = ref(0)
const isActive = ref()
const pageSelected = ref()
const $cookies = inject('$cookies')
const token = ref()
const openForm = ref(false)
const email = ref('')
const emit = defineEmits(['reloadUser'])

onMounted(async ()=>{
  isActive.value = userAnn.getMode()
  pageSelected.value = userAnn.getPage() === undefined ? 0 : userAnn.getPage()
  userAnn.setCategory(category.value)
  if($cookies.get("token") !== null){
    token.value = "Bearer " + $cookies.get("token")
    const userInfo = parseJwt(token.value)
    console.log(userInfo)
    if(userInfo.email !== null){
      email.value = userInfo.email
    }
  }
  await loadCategory()
  if(isActive.value){
    await loadActiveAnnouncement(category.value,pageSelected.value,token.value)
  }else{
    await loadClosedAnnouncement(category.value,pageSelected.value,token.value)
  }
})


const countItems = (index) =>{
  pageSelected.value = userAnn.getPage() === undefined ? 0 : userAnn.getPage()
  const numberPerPage = 5
  let item = index+1
  let startNumber = ((pageSelected.value)*numberPerPage)
  return startNumber+item
}



const changeCategory = async () =>{
  pageSelected.value = 0
  userAnn.setPage(pageSelected.value)
  if(isActive.value){
    await loadActiveAnnouncement(category.value,pageSelected.value,token.value)
  }else{
    await loadClosedAnnouncement(category.value,pageSelected.value,token.value)
  }
}
const loadCategory = async () =>{
    await fetch(FETCH_API+'/categories')
    .then(res => res.json())
    .then(data => categories.value = data)
    .catch((err) => errorMessage.value = err)
}

const showDescription = (announcementId) =>{
  router.push({
    name : 'userDesc',
    params : {id : announcementId}
  })
  
}

const switchMode = async () =>{
  isActive.value = userAnn.setMode()
  pageSelected.value = 0
  userAnn.setPage(pageSelected.value)
  if(isActive.value){
    await loadActiveAnnouncement(category.value,pageSelected.value)
  }else{
    await loadClosedAnnouncement(category.value,pageSelected.value)
  }
}

const changePage = async (pageNumber) =>{
  userAnn.setPage(pageNumber)
  pageSelected.value = pageNumber
  if(isActive.value){
    await loadActiveAnnouncement(category.value,pageNumber)
  }else{
    await loadClosedAnnouncement(category.value,pageNumber)
  }
}
const loadActiveAnnouncement = async (catId,pageNumber = 0,token)=>{
   await fetch(`${FETCH_API+'/announcements'}/pages?mode=active&category=${catId}&page=${pageNumber}`)
          .then(res => res.json())
          .then(data => announcementData.value = data)
          .catch((err) => errorMessage.value = err)
}

const loadClosedAnnouncement = async (catId,pageNumber = 0,token)=>{
  await fetch(`${FETCH_API+'/announcements'}/pages?mode=close&category=${catId}&page=${pageNumber}`)
          .then(res => res.json())
          .then(data => announcementData.value = data)
          .catch((err) => errorMessage.value = err)
}
const maxPage = () =>{
  return announcementData.value.totalPages <= 10 ? announcementData.value.totalPages : 10
}
const pageRange = () =>{
  let i = 1
  let range = []
  let max = pageSelected.value+1 <= 10 ? maxPage() : pageSelected.value+1
  for(i;i<=max;i++){
    range.push(i)
  }
  
  if(pageSelected.value+1 <= 10){
    return range
  }
  return range.slice(-10)
}
const subscibeForm = async () =>{
  if(openForm.value === false){
    openForm.value = true
  }else if(email.value.trim().length === 0 && openForm.value === true){
    openForm.value = false
  }else{
    const data = {
      email : email.value.trim(),
      categoryId : category.value
    }
    await fetch(FETCH_API + '/subscribe/verify',{
      method : "POST",
      headers: {
      "Content-Type": "application/json",
      },
      body: JSON.stringify(data)
    })
    .then(openForm.value = false)
  }
}
</script>
<template>
     

    <div class=" w-full flex">
      <div class=" w-full flex flex-col p-2" >  
        <h3 class="text-lg font-semibold mt-4 ml-5">Date/Time shown in Timezone : {{ Intl.DateTimeFormat().resolvedOptions().timeZone }}</h3>
        <label class="ml-5 mt-3 mb-2 flex flex-col">
          <div class="flex" >
            <span class="block text-sm font-medium text-slate-700 mr-3 mt-1 ml-2 ">Choose Category :</span>
            <select name="category" class="ann-category-filter ann-category rounded-md border p-1  mb-3" v-model="category" @change="changeCategory">
                <option :value="0" > ทั้งหมด </option>
                <option v-for="cat in categories" :value="cat.id">{{ cat.categoryName }}</option> 
            </select> 
          </div>
          <div class="space-x-1">
            <input type="email" class="input input-bordered input-accent w-full max-w-xs" name="email" placeholder="Enter your email" v-model="email" v-if="openForm">
              <label :for="!openForm  && String(email).trim().length !== 0? 'my_modal_6' : ''" @click="subscibeForm" class="btn btn-success">Subscribe</label>
              <label @click="email = ''" class="btn btn-error" v-if="openForm && String(email).trim().length !== 0">Clear</label>
           
          </div>
        </label>
     
        <!-- <button class="btn btn-success w-40 "><div class="flex mr-2"><span class="ml-3 mt-1 mr-2">Subscription</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 24 24"><path fill="currentColor" d="M4 20q-.825 0-1.413-.588T2 18V6q0-.825.588-1.413T4 4h16q.825 0 1.413.588T22 6v4.35l-6.025 6.025l-1.45-1.45q-.575-.575-1.425-.575t-1.425.575L10.3 16.3q-.575.575-.575 1.425t.575 1.425l.85.85H4Zm8-9L5.3 6.8q-.425-.275-.862-.025T4 7.525q0 .225.1.413t.3.312l7.075 4.425q.25.15.525.15t.525-.15L19.6 8.25q.2-.125.3-.313t.1-.412q0-.5-.437-.75T18.7 6.8L12 11Zm3.95 8.2l4.95-4.95q.275-.275.7-.275t.7.275q.275.275.275.7t-.275.7l-5.65 5.65q-.3.3-.7.3t-.7-.3l-2.85-2.85q-.275-.275-.275-.7t.275-.7q.275-.275.7-.275t.7.275l2.15 2.15Z"/></svg>
       </div></button> -->
        
    </div>
  <!-- Closed Announcement-->
      <div class=" w-full  p-2  mt-3 justify-end flex  ">
        <div class="w-3/5 space-x-2  justify-end flex" >
            <button id="text-but" @click="switchMode" class="ann-button  mr-5 p-2 buttonclose btn">
                  <h1  class="pl-2 ">{{ isActive ? 'Closed Announcement' : 'Active Announcement'  }}</h1></button>
        </div>
      </div>
  </div>  
      
 <!-- table-->     
    <div class="overflow-x-auto">
      <table class="table table-zebra w-full ">
        <thead>
          <tr class="text-left">
            <th>No</th>
            <th>Title</th>
            <th v-if="!isActive">Close Date</th>
            <th>Category</th>
          </tr>
        </thead>
        <tbody v-if="announcementData.content !== null || Object(announcementData.content).length !== 0">
          <tr class="ann-item text-left" v-for="announcement,index in announcementData.content">
            <th>{{ countItems(index) }}</th>
            <td @click="showDescription(announcement.id)" class="ann-title ">{{ announcement.announcementTitle }}</td>
            <td class="ann-close-date" v-if="!isActive">{{ announcement.closeDate === null ? '-' : formatDate(announcement.closeDate) }}</td>
            <td class="ann-category">{{ announcement.announcementCategory }}</td>
          </tr>
        </tbody>
      </table>
      <h3 v-if="Object(announcementData.content).length === 0 " class="mt-3 text-center text-red-600 font-bold">No Announcement</h3>
      <img v-if="Object(announcementData.content).length === 0" src="https://i.gifer.com/XOsX.gif" alt="Computer man" style="width:60px;height:60px; margin-left: 48%;">
    </div>
    
  <!-- button page -->   
    <div class="pagination" v-if="Object(announcementData.content).length !== 0 && announcementData.totalPages > 1">
      <div class="btn-group">
        <button class="ann-page-prev btn btn-sm btn-warning hover:border-black " :disabled="announcementData.first" @click="changePage(pageSelected-1)">&laquo; Prev</button>
        <button class="btn btn-sm hover:border-black" v-for="page,index in pageRange()" :class="[pageSelected+1 === page ? 'glass text-black' : 'btn-warning',
        `ann-page-${index}`]"  @click="changePage(--page)">{{ page }}</button>
        <button class="ann-page-next btn btn-sm btn-warning hover:border-black" :disabled="announcementData.last" @click="changePage(pageSelected+1)">Next &raquo;</button>
      </div>
      <div class="text-center text-sm font-bold mt-2">
        <span>PAGE : {{ pageSelected+1 }} of {{ announcementData.totalPages }}</span>
      </div>
    </div>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my_modal_6" class="modal-toggle" />
<div class="modal">
  <div class="modal-box">
    <h3 class="font-bold text-lg">Thanks for subscription</h3>
    <p class="py-4">Confirmation email was sent to {{ email }}</p>
    <div class="modal-action">
      <label for="my_modal_6" class="btn">Close!</label>
    </div>
  </div>
</div>
</template>

<style>
/* ---- button close---- */
.buttonclose{
    border: 1px solid #2c2c2c;
    background-color: #2c2c2c;
  color: rgb(255, 255, 255); 
}
.buttonclose:hover{
    border: 1px solid #55a92d;
    background-color: #55a92d;
  color: rgb(255, 255, 255); 
}
/* ----page button---- */

.pagination {
  margin: 25px;
    position: relative;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-60%);
  display: inline-block;
}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  border: 1px solid #ddd;
  
}

.pagination a.active {
  background-color: #1975de;
  color: white;
  border: 1px solid #1975de;
}
.pagination a:hover:not(.active) {background-color: #ddd;}

.pagination a:first-child {
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
}

.pagination a:last-child {
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
}



</style>
