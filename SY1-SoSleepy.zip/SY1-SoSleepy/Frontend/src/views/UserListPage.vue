<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router'
import { formatDate } from '../composable/formatDate'
import { inject } from 'vue'
import { parseJwt } from '../composable/getToken'
const $cookies = inject('$cookies')
const token = ref('')
const router = useRouter()
const errorMessage = ref()
const FETCH_API = import.meta.env.VITE_API
const userData = ref({})
const payload = ref({})
const emit = defineEmits(['reloadUser'])
onMounted(async ()=>{
  token.value = "Bearer " + $cookies.get("token")
  if(token.value !== null){
      payload.value = parseJwt($cookies.get("token"))
    }
    if(payload.value.role !== 'admin'){
      alert("ACCESS DENIED")
      router.back()
    }
  await getUserData(token.value)
  
})

const addUser = () =>{
  router.push('/admin/user/add')
}

//GET
const getUserData = async (token) =>{
  await fetch(FETCH_API + '/users',{
    headers:{
      'Authorization': token
    }
  })
  .then(res => res.json())
  .then(data => userData.value = data)
  .catch((err) => errorMessage.value = err)
}

//EDIT
const editUser = (userId) =>{
  router.push({
    name : 'UserEdit',
    params : {id : userId}
  })
}
//DELETE
const deleteUser = async (userId) =>{
  let result = confirm('Confirm to delete this announcement. Do you want to delete it?')
  if(result){
    await fetch(FETCH_API + '/users/' + userId,{
      headers:{
        'Authorization': token.value
      },
      method : "DELETE"
    })
    .then(async (res)=> {
      if(res.ok){
        router.go(0)
      }else if(res.status === 403){
        alert("You cannot delete yourself!!")
      }else{
        alert("Could not delete the user")
      }
      await getUserData(token.value)
    })
    .catch(err => alert(err))
  }
  
}

const countItems = (index) =>{
  const numberPerPage = 5
  let item = index+1
  return item
}
</script>
<template>
  <div class="w-full">
    <div class="flex flex-col space-y-5">
      <div class="w-full flex justify-center">
        <div class="lg:w-5/6 md:w-1/2 sm:w-4/5 min-w-max justify-between sm:flex sm:flex-col md:flex md:flex-row lg:flex lg:flex-row">
          <div class="flex flex-col min-w-fit w-1/2">
            <div class="flex w-full  mt-5 ml-5">
              <svg class="mr-3 text-amber-800" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 256 256"><path fill="currentColor" d="M125.18 156.94a64 64 0 1 0-82.36 0a100.23 100.23 0 0 0-39.49 32a12 12 0 0 0 19.35 14.2a76 76 0 0 1 122.64 0a12 12 0 0 0 19.36-14.2a100.33 100.33 0 0 0-39.5-32ZM44 108a40 40 0 1 1 40 40a40 40 0 0 1-40-40Zm206.1 97.67a12 12 0 0 1-16.78-2.57A76.31 76.31 0 0 0 172 172a12 12 0 0 1 0-24a40 40 0 1 0-14.85-77.16a12 12 0 1 1-8.92-22.28a64 64 0 0 1 65 108.38a100.23 100.23 0 0 1 39.49 32a12 12 0 0 1-2.62 16.73Z"/></svg>
              <h1 class="font-semibold text-2xl text-end text-amber-600 ">User Management</h1>
            </div>
          <div class="flex w-full mt-5 ml-5">
            <h3 class="text-lg font-semibold mt-3 mb-3 ml-5">Date/Time shown in Timezone : <span class="font-medium text-yellow-600">{{ Intl.DateTimeFormat().resolvedOptions().timeZone }}</span></h3>    
          </div>
          </div>
          <div class="ml-3 justify-end flex mt-auto" >
            <!-- <button @click="addUser" class="ann-button mr-5 p-2 btn hover:bg-transparent hover:text-black hover:border-yellow-400 hover:border-4 bg-yellow-400"></button> -->
              <button @click="addUser" class="ann-button mr-5 p-2 flex btnhead rounded-md ">
                <svg xmlns="http://www.w3.org/2000/svg" class="mt-1" width="20" height="20" viewBox="0 0 24 24"><path fill="currentColor" d="M20 14h-6v6h-4v-6H4v-4h6V4h4v6h6v4Z"/></svg>
                <h1 class="pl-2 mr-2 font-semibold">Add User</h1>
              </button>
          </div>
        </div>
      </div>
      
      <div class="overflow-x-auto w-full justify-center flex ">
        <table class="table table-zebra w-4/5 border-b-2 border-yellow-500 min-w-fit">
          <thead>
            <tr class="text-left">
              <th>No</th>
              <th>username</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Created On</th>
              <th>Updated On</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr class="ann-item hover:border hover:border-black" v-for="user,index in userData">
              <td class="font-semibold">{{ countItems(index) }}</td>
              <td class="ann-username">{{ user.username }}</td>
              <td class="ann-name">{{ user.name }}</td>
              <td class="ann-email">{{ user.email }}</td>
              <td class="ann-role">{{ user.role }}</td>
              <td class="ann-created-on">{{ formatDate(user.createdOn) }}</td>
              <td class="ann-updated-on">{{ formatDate(user.updatedOn) }}</td>
              <td class="space-x-2 justify-center">
                <button class="ann-button btn btn-outline btn-info" @click="editUser(user.id)">edit</button>
                <button class="ann-button btn btn-outline btn-error" @click="deleteUser(user.id)" >delete</button>
              </td>
            </tr>
          </tbody>
        </table>
        <h3 v-if="userData.length === 0" class="mt-3 text-center text-red-600 font-bold">No User</h3>
        <img v-if="userData.length === 0" src="https://i.gifer.com/XOsX.gif" alt="Computer man" style="width:60px;height:60px; margin-left: 48%;">
      </div>
    </div>
  </div>
<!-- v-if="Object(announcementData.content).length !== 0 && announcementData.totalPages > 1" -->
    <!-- <div class="pagination" >
      <div class="btn-group">
        <button class="btn btn-sm btn-warning hover:border-black" :disabled="first" @click="changePage(pageSelected-1)">&laquo; Prev</button>
        <button class="btn btn-sm hover:border-black" :class="pageSelected+1 === page ? 'glass text-black' : 'btn-warning'" v-for="page in pageRange()" @click="changePage(--page)">{{ page }}</button>
        <button class="btn btn-sm hover:border-black" :class="pageSelected+1 === pageSelected+1 ? 'glass text-black' : 'btn-warning'" v-if="pageSelected+1 > pageRange()">{{ pageSelected+1 }}</button>
        <button class="btn btn-sm btn-warning hover:border-black" :disabled="last" @click="changePage(pageSelected+1)">Next &raquo;</button>
      </div>
      <div class="text-center text-sm font-bold mt-2">
        <span>PAGE : {{ pageSelected+1 }} of {{ totalPage }}</span>
      </div>
    </div>  -->
</template>

<style>
.buttonAdd{
    border: 1px solid #2c2c2c;
    background-color: #2c2c2c;
  color: rgb(255, 255, 255); 
}
.buttonAdd:hover{
    border: 1px solid #55a92d;
    background-color: #55a92d;
  color: rgb(255, 255, 255); 
}
.tb-shadow {
  box-shadow: 0px 0px 7px 1px rgba(0,0,0,0.82);
-webkit-box-shadow: 0px 0px 7px 1px rgba(0,0,0,0.82);
-moz-box-shadow: 0px 0px 7px 1px rgba(0,0,0,0.82);
}
.inner-shadow :hover{
  box-shadow: 0px 0px 20px 1px rgba(0,0,0,0.41) inset;
  -webkit-box-shadow: 0px 0px 20px 1px rgba(0,0,0,0.41) inset;
  -moz-box-shadow: 0px 0px 20px 1px rgba(0,0,0,0.41) inset;
}
.btnhead{
  background-color: #fed037;
  border: 2px solid #fed037;
}
.btnhead:hover{
  background-color: #ffffff;
  border: 3px solid #fed037;
}

</style>