<script setup>
import {ref, onMounted } from 'vue';
import { useRoute ,useRouter } from 'vue-router'
import { formatDate } from '../composable/formatDate'
import { inject } from 'vue'
const $cookies = inject('$cookies')
const router = useRouter()
const { params } = useRoute()
const FETCH_API = import.meta.env.VITE_API
const announcementDetail = ref([])
const errorMSG = ref('')
const token = ref('')

onMounted(async()=>{
    token.value = "Bearer " + $cookies.get("token")
    loadDetail(token.value)
})

const loadDetail = async (token) =>{
    try {
        const res = await fetch(`${FETCH_API+'/announcements'}/${params.id}`,{
    headers:{
      'Authorization': token
    }
  })
        if(!res.ok){
            alert('The request page is not available')
            router.push({
                name : 'home'
            })
            throw new Error(res.status)
        }else{
            announcementDetail.value = await res.json()
        }
    }catch(err){
        errorMSG.value = err
    }
}
const editAnnouncement = (annId) =>{
    router.push({
        name : 'edit',
        params : {id : annId}
    })
}
</script>

<template >


     
    <div class="w-full mt-16">
        <div class="w-3/5 mt-4 relative m-auto">
        <div class=" mb-5 p-5 rounded-lg  div" style="line-height:50px">
            
            <div class="flex gap-1 items-center justify-start">
                <svg  class=" text-black mt-3 ml-2" width="30" height="30" xmlns="http://www.w3.org/2000/svg" ><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21L4 22l.99-3.95l5.43-5.44Z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5M4 13.5V6a2 2 0 0 1 2-2h2"/></g></svg>
                <h1 class=" font-bold font-serif text-black mt-3 ">Announcement Detail</h1>
            </div>
            <hr class=" font-bold mb-5"/>
            <table class="ann-item">
                <tr >
                <div class="flex">
                    <svg xmlns="http://www.w3.org/2000/svg"  class="mt-3" width="20" height="28" viewBox="0 0 256 256"><path fill="currentColor" d="m230.14 70.54l-44.68-44.69a20 20 0 0 0-28.29 0L33.86 149.17A19.85 19.85 0 0 0 28 163.31V208a20 20 0 0 0 20 20h44.69a19.86 19.86 0 0 0 14.14-5.86L230.14 98.82a20 20 0 0 0 0-28.28ZM91 204H52v-39l84-84l39 39Zm101-101l-39-39l18.34-18.34l39 39Z"/></svg>
                    <td><span class="font-bold ml-2 ">Title </span></td>
                </div>                 
                    <td class="ann-title pl-10" >{{ announcementDetail.announcementTitle}}</td>
                </tr>
                <tr >
                <div class="flex">
                    <svg   xmlns="http://www.w3.org/2000/svg" class="mt-3" width="20" height="28" viewBox="0 0 16 16"><g fill="currentColor"><path d="M6 4.5a1.5 1.5 0 1 1-3 0a1.5 1.5 0 0 1 3 0zm-1 0a.5.5 0 1 0-1 0a.5.5 0 0 0 1 0z"/><path d="M2 1h4.586a1 1 0 0 1 .707.293l7 7a1 1 0 0 1 0 1.414l-4.586 4.586a1 1 0 0 1-1.414 0l-7-7A1 1 0 0 1 1 6.586V2a1 1 0 0 1 1-1zm0 5.586l7 7L13.586 9l-7-7H2v4.586z"/></g></svg>
                    <td><span class="font-bold ml-2 ">Category </span></td>
                </div>
                    <td class="ann-category pl-10" >{{ announcementDetail.announcementCategory }}</td>
                </tr>
                <tr>
                    <div class="flex">
                        <svg xmlns="http://www.w3.org/2000/svg" class="mt-3" width="20" height="28" viewBox="0 0 256 256"><path fill="currentColor" d="M216 44H40a20 20 0 0 0-20 20v160a19.82 19.82 0 0 0 11.56 18.1a20.14 20.14 0 0 0 8.49 1.9a19.91 19.91 0 0 0 12.82-4.72l.19-.16L84 212h132a20 20 0 0 0 20-20V64a20 20 0 0 0-20-20Zm-4 144H82.5a20 20 0 0 0-12.87 4.69l-.19.16L44 215.14V68h168ZM84 108a12 12 0 0 1 12-12h64a12 12 0 1 1 0 24H96a12 12 0 0 1-12-12Zm0 40a12 12 0 0 1 12-12h64a12 12 0 0 1 0 24H96a12 12 0 0 1-12-12Z"/></svg>
                        <td><span class="font-bold ml-2 ">Description </span></td>
                    
                </div>
                    <td class="ann-description pl-10 ql-editor" v-html="announcementDetail.announcementDescription" contentType="html"></td>
                
                </tr>
                <tr >
                <div class="flex">
                    <svg  xmlns="http://www.w3.org/2000/svg" class="mt-3" width="20" height="28" viewBox="0 0 24 24"><path fill="currentColor" d="m22 5.72l-4.6-3.86l-1.29 1.53l4.6 3.86L22 5.72zM7.88 3.39L6.6 1.86L2 5.71l1.29 1.53l4.59-3.85zM12.5 8H11v6l4.75 2.85l.75-1.23l-4-2.37V8zM12 4c-4.97 0-9 4.03-9 9s4.02 9 9 9a9 9 0 0 0 0-18zm0 16c-3.87 0-7-3.13-7-7s3.13-7 7-7s7 3.13 7 7s-3.13 7-7 7z"/></svg>
                    <td><span class="font-bold ml-2 ">PublishDate </span></td>
                    </div>
                    <td class="ann-publish-date pl-10" >{{ announcementDetail.publishDate === null || announcementDetail.publishDate === undefined ? '-' :  formatDate(announcementDetail.publishDate)}}</td>
                </tr>
                <tr >
                <div class="flex">
                    <svg  xmlns="http://www.w3.org/2000/svg" class="mt-3" width="20" height="28" viewBox="0 0 24 24"><path fill="currentColor" d="M10.04 6.29C10.66 6.11 11.32 6 12 6c3.86 0 7 3.14 7 7c0 .68-.11 1.34-.29 1.96l1.56 1.56c.47-1.08.73-2.27.73-3.52A9 9 0 0 0 8.47 4.72l1.57 1.57zm7.297-4.48l4.607 3.845l-1.28 1.535l-4.61-3.843zm1.903 16.51l-1.43-1.43l-9.7-9.7l-1.43-1.43l-.74-.74L4.52 3.6l-1.5-1.5l-1.41 1.41l1.37 1.37l-.92.77l1.28 1.54l1.06-.88l.8.8A8.964 8.964 0 0 0 3 13a9 9 0 0 0 9 9c2.25 0 4.31-.83 5.89-2.2l2.1 2.1l1.41-1.41l-2.16-2.17zM12 20c-3.86 0-7-3.14-7-7c0-1.7.61-3.26 1.62-4.47l9.85 9.85A6.956 6.956 0 0 1 12 20zM7.48 3.73l.46-.38l-1.28-1.54l-.6.5z"/></svg>
                    <td><span class="font-bold ml-2">CloseDate </span></td>
                </div>
                    <td class="ann-close-date pl-10 " >{{ announcementDetail.closeDate === null || announcementDetail.closeDate === undefined ? '-' : formatDate(announcementDetail.closeDate) }}</td>
                </tr>
                <tr >
                <div class="flex">
                    <svg xmlns="http://www.w3.org/2000/svg" class="mt-3" width="20" height="28" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="18" height="18" x="3" y="3" rx="4"/><path d="m9 12l2.25 2L15 10"/></g></svg>
                    <td><span class="font-bold ml-2">Display </span></td>
                </div>
                    <td class="ann-display pl-10" >{{ announcementDetail.announcementDisplay}}</td>
                </tr>
                <tr>
                    <div class="flex">
                        <svg xmlns="http://www.w3.org/2000/svg" class="mt-3" width="20" height="28" viewBox="0 0 256 256" ><path fill="currentColor" d="M247.31 124.76c-.35-.79-8.82-19.58-27.65-38.41C194.57 61.26 162.88 48 128 48S61.43 61.26 36.34 86.35C17.51 105.18 9 124 8.69 124.76a8 8 0 0 0 0 6.5c.35.79 8.82 19.57 27.65 38.4C61.43 194.74 93.12 208 128 208s66.57-13.26 91.66-38.34c18.83-18.83 27.3-37.61 27.65-38.4a8 8 0 0 0 0-6.5ZM128 192c-30.78 0-57.67-11.19-79.93-33.25A133.47 133.47 0 0 1 25 128a133.33 133.33 0 0 1 23.07-30.75C70.33 75.19 97.22 64 128 64s57.67 11.19 79.93 33.25A133.46 133.46 0 0 1 231.05 128c-7.21 13.46-38.62 64-103.05 64Zm0-112a48 48 0 1 0 48 48a48.05 48.05 0 0 0-48-48Zm0 80a32 32 0 1 1 32-32a32 32 0 0 1-32 32Z"/></svg>
                    <td><span class="font-bold ml-2">Views </span></td>
                </div>
                    <td class="ann-counter pl-10" >{{ announcementDetail.viewCount}}</td>
                </tr>
                
            </table>
           
        </div>
        <router-link to="/admin/announcement"><button class="ann-button mb-6 btn buttonBack ">Back</button></router-link>
        <button @click="editAnnouncement(announcementDetail.id)" class="ann-button ml-10 mb-6 btn buttonEdit">Edit</button> 
   
    </div>
</div>
   

</template>

<style scoped>
/* ิ---------Button--------- */
.buttonBack{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255); 
}
.buttonBack:hover{
    border: 2px solid #0473aa;
    background-color: #0473aa;
  color: rgb(255, 255, 255); 
}
.buttonEdit{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255); 
}
.buttonEdit:hover{
    border:2px solid #5eb706;
    background-color: #5eb706;
  color: rgb(255, 255, 255); 
}
/* ----------bg----------- */
.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}


body, html {
  padding: 0;
  margin: 0;
  width: 100%;
  min-height: 100vh;
}
body {
  background-color: #262626;
}
ol li {
    list-style: decimal;
    list-style-position: inside;
}
</style>
