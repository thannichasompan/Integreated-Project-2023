<script setup >
import { ref,computed, onMounted } from 'vue';
import { useRouter } from 'vue-router'
import warningIcon from '../icons/warningIcon.vue'
import errorIcon from '../icons/errorIcon.vue'
import successIcon from '../icons/successIcon.vue'
import informationIcon from '../icons/informationIcon.vue'
import { inject } from 'vue'
const $cookies = inject('$cookies')
const FETCH_API = import.meta.env.VITE_API
const token = ref('')

const router = useRouter()
const errorMessage = ref()
const roles = ["admin","announcer"]
const dataCheck = ref(false)
const requirement = ref('')
const passRequireText = ref('')
const emailRequireText = ref('')
const confirmPassRequireText = ref('')
const passBlock = ref(false)
const emailBlock = ref(false)
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%^#&*()_+{}\[\]:;<>,.?/~\\|-])[\S]{8,14}$/
const emailRegex = /^[^@]+@[^@]+\.[^.]{1,3}$/
const responseError = ref({})
const validateData = ref(false)
const usernameWarning = ref('')
const passwordWarning = ref('')
const confirmPassWarning = ref('')
const nameWarning = ref('')
const emailWarning = ref('')

//PAGE
const username = ref('')
const name = ref('')
const email = ref('')
const role = ref("announcer")
const password = ref('')
const conPass = ref('')
const newUser = {
    username : '',
    name : '',
    email : '',
    role : ''
}
onMounted(async () => {
    token.value = "Bearer " + $cookies.get("token")
  
})

const cancel =()=>{
    let result = confirm('Confirm to cancel ')
    if(result)router.push({name : 'UserList'})
}

const enableAdd = computed(()=>{
    if(String(username.value).trim().length === 0){
      dataCheck.value = true
      requirement.value = "Username cannot be empty!!!"
    }else if(password.value.trim().length === 0){
      dataCheck.value = true
      requirement.value = "Password cannot be empty!!!" 
    }else if(conPass.value.trim().length === 0){
      dataCheck.value = true
      requirement.value = "Confirm password cannot be empty!!!" 
    }else if(String(name.value).trim().length === 0){
      dataCheck.value = true
      requirement.value = "Name cannot be empty!!!" 
    }else if(String(email.value).trim().length === 0){
      dataCheck.value = true
      requirement.value = "Email cannot be empty!!!"
    }else{
      dataCheck.value = false
      requirement.value = ""
    }
    // Password pattern
    if(!passwordRegex.test(password.value)){
        passRequireText.value = 'Password must be include number, uppercase, lowercase and special characters. Do not include whitespace'
        passBlock.value = true
    }else{
        passRequireText.value = ''
        passBlock.value = false
    }
    //Email pattern
    if(!emailRegex.test(email.value)){
        emailBlock.value = true
        emailRequireText.value = "example : exemple@email.com"
    }else{
        emailBlock.value = false
    }
    // Confirm password
    if(password.value !== conPass.value){
        confirmPassRequireText.value = 'The password DOES NOT match'
    }
    return dataCheck.value || emailBlock.value || passBlock.value || password.value !== conPass.value
})

const submit = async (token)=>{
    usernameWarning.value = ''
    passwordWarning.value = ''
    nameWarning.value = ''
    emailWarning.value = ''

    newUser.value = {
        username : username.value.trim(),
        password : password.value.trim(),
        name : name.value.trim(),
        email : email.value.trim(),
        role : role.value
    }
    await fetch(FETCH_API + '/users',{
        method : 'POST',
        headers : {
            "Content-Type": "application/json",
            'Authorization': token
        },
        body : JSON.stringify(newUser.value)
    })
    .then(async (res) => {
        if(res.ok){
            alert('Added user successfully')
            router.push('/admin/user')
        }else{
            responseError.value = await res.json()
            if(responseError.value.status === 400){
                validateData.value = true
                for(const data of responseError.value.detail){
                    if(data.field === "username") usernameWarning.value = data.errorMessage
                    if(password.value.trim() === conPass.value.trim()){
                        if(data.field === "password" && data.errorMessage.length > 30 && password.value.length >= 8){
                            passwordWarning.value = "Password " + data.errorMessage
                            confirmPassWarning.value = "Confirm password " + data.errorMessage
                        }else if(data.field === "password" && data.errorMessage.length < 30 && password.value.length < 8){
                            passwordWarning.value = "Password " + data.errorMessage
                            confirmPassWarning.value = "Confirm password " + data.errorMessage
                        }
                    }else{
                        passwordWarning.value = "The password DOES NOT match"
                        confirmPassWarning.value = "The password DOES NOT match"
                    }
                    if(data.field === "name") nameWarning.value = data.errorMessage
                    if(data.field === "email") emailWarning.value = data.errorMessage
                }
            }
        }
    })
    .catch(err => errorMessage.value = err)
}


</script>
 
<template>
 
    <!-- p =ใน m=นอก -->
    <div class="w-full mt-16">
        <form @submit.prevent="handleSubmit">
        <div class="w-3/5 mt-4 relative m-auto">
        <div class=" mb-5 p-5 rounded-lg  div" style="line-height:50px">
            <div class="flex gap-1 items-center justify-start">
                <svg  class=" text-black mt-3 ml-2" width="30" height="30" xmlns="http://www.w3.org/2000/svg" ><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21L4 22l.99-3.95l5.43-5.44Z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5M4 13.5V6a2 2 0 0 1 2-2h2"/></g></svg>
                <h1 class=" font-bold font-serif text-black mt-3 ">Add User </h1>
            </div>
            <hr class=" font-bold mb-5"/>
            
            <!-- Username oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')"-->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 ">Username <span class="text-red-700">*</span></span>
                <div class="flex">
                    <input type="text" placeholder="Type your username here..." pattern="^(?!\s+$).+" oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')" v-on:keyup.enter="submit(token)" class="ann-username  input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="45" v-model="username" required/>
                    <div class="flex flex-row justify-between w-20">
                        <span class="text-sm font-medium text-slate-700 ml-2 mt-3">({{ username.length }}/45)</span>
                    </div>
                </div>
            </label>
            <!-- Warning for Username field -->
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && usernameWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-username">{{ usernameWarning }}</span>
            </div>

            <!-- Password -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4 ">Password <span class="text-red-700">*</span></span>
                <div class="flex">
                <input type="password" placeholder="Type your password here..." pattern="^(?!\s+$).+" oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')" v-on:keyup.enter="submit(token)" class="ann-password input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="14" v-model="password" required/>
                <div class="flex flex-row justify-between w-20">
                    <span class="text-sm font-medium text-slate-700 ml-2 mt-3">({{ password.length }}/14) </span> 
                    <span class="mt-3"><successIcon class="text-green-800" v-if="!passBlock"/></span>   
                </div>
            </div>
            </label>
            <!-- Warning for Password field -->  
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && passwordWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-password">{{ passwordWarning }}</span>
            </div>
            <!-- Information for Password -->
            <div class="flex gap-1 items-center justify-start text-black" v-if="passBlock">
                <informationIcon/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 text-black">{{ passRequireText }}</span>
            </div>
            
            <!-- Confirm Password -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4 ">Confirm password <span class="text-red-700">*</span></span>
                <div class="flex">
                <input type="password" placeholder="Confirm your password here..." pattern="^(?!\s+$).+" oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')" v-on:keyup.enter="submit(token)" class="ann-confirm-password input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="14" v-model="conPass" required/>
                    <div class="flex flex-row justify-between w-20">
                        <span class="text-sm font-medium text-slate-700 ml-2 mt-3">({{ conPass.length }}/14) </span>
                        <span><successIcon class="mt-3 text-green-800" v-if="password.length !== 0 && conPass.length !== 0 && password === conPass && passwordRegex.test(password)"/></span>
                        <span><errorIcon class="mt-3 text-red-600" v-if="password.length !== 0 && conPass.length !== 0 && password !== conPass && !passwordRegex.test(password)"/></span> 
                    </div>
                </div>
            </label>
            <!-- Warning for Password field -->  
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && passwordWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-confirm-password">{{ confirmPassWarning }}</span>
            </div>
            <!-- <div class="flex gap-1 items-center justify-start text-red-600" v-if="password !== conPass">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1">{{ confirmPassRequireText }}</span>
            </div> -->
            
            <!-- Name -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4">Name <span class="text-red-700">*</span></span>
                <input  type="text" placeholder="Type your name here..." pattern="^(?!\s+$).+" oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')" v-on:keyup.enter="submit(token)" class="ann-name  input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="100" v-model="name" required/>
                <span class="text-sm font-medium text-slate-700 ml-2">({{ name.length }}/100)</span> 
            </label>
            <!-- Warning for Name field -->  
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && nameWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-name">{{ nameWarning }}</span>
            </div>

            <!-- Email -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4 ">Email <span class="text-red-700">*</span></span>
                <div class="flex">
                    <input  type="email" placeholder="Type your email here..." pattern="^(?!\s+$).+" class="ann-email input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="150" v-on:keyup.enter="submit(token)" v-model="email" required/>
                    <div class="flex flex-row justify-between w-20">
                        <span class="text-sm font-medium text-slate-700 ml-2 mt-3">({{ email.length }}/150)</span>
                        <span><successIcon class="mt-3 ml-1 text-green-800" v-if="!emailBlock"/></span>
                        <span><errorIcon class="mt-3 ml-1 text-red-600" v-if="emailBlock && email.length > 0" /></span> 
                    </div>
                </div>
            </label>
            <!-- Warning for Email field -->  
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && emailWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-email">{{ emailWarning }}</span>
            </div>

            
            <!-- Role -->
            <label class="block  mt-3 ">
                <span class="block text-sm font-medium text-slate-700  ">Role<span class="text-red-700">*</span></span>
                <select class="ann-role rounded-md border p-1" v-model="role">
                    <option v-for="role in roles" :value="role">{{ role }}</option>
                </select>
            </label>

            <!-- Warning Text -->
            <div class="alert alert-error justify-start w-full h-12 mt-3 overflow-scroll overflow-x-hidden overflow-y-hidden" v-if="dataCheck && !validateData">
                <errorIcon />
                <span class="font-semibold">{{ requirement }}</span>
            </div>
            <div class="alert alert-success justify-start w-full h-12 mt-3 overflow-scroll overflow-x-hidden overflow-y-hidden" v-if="!enableAdd && !validateData">
                <successIcon />
                <span class="font-semibold">SAVE button.</span>
            </div>
            <div class="alert alert-error justify-start w-full h-12 mt-3 overflow-scroll overflow-x-hidden overflow-y-hidden" v-if="validateData">
                <errorIcon />
                <span class="font-semibold">Please change the information that is invalid !!</span>
            </div>
        </div>
         <!-- Button    :disabled="enableAdd" -->
            <button @click="submit(token)" class="ann-button btn buttonSubmit" type="submit" >Save</button>
            <button @click="cancel" class="ann-button ml-5 mb-6 btn buttonCancle">Cancel</button>
        </div>
        </form>
    </div>
</template>

<style scoped>
.buttonSubmit{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255);  
}
.buttonSubmit:hover{
    border:2px solid #5eb706;
    background-color: #5eb706;
  color: rgb(255, 255, 255); 
}
/* -------------------------------------------- */
.buttonCancle{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255); 
}
.buttonCancle:hover{
    border: 2px solid #d43a1b;
    background-color: #d43a1b;
  color: rgb(255, 255, 255); 
}

.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}
body, html {
  padding: 0;
  margin: 0;
  width: 100%;
  min-height: 100vh;
}
body {
  background-color: #262626;
}


.Desc{
    border-radius: 15px;
    background-color: #ffffff;
    width: 60%;
}
hr {
  border: 1px solid rgb(255, 255, 255);
}

</style>