<script setup >
import { ref, onMounted } from 'vue'
import errorIcon from '../icons/errorIcon.vue'
import successIcon from '../icons/successIcon.vue'
import { inject } from 'vue'
import { parseJwt } from '../composable/getToken'
import router from '../router'
const $cookies = inject('$cookies')
const token = ref('')
const FETCH_API = import.meta.env.VITE_API
const emit = defineEmits(['reloadUser'])
//PAGE
const username = ref('')
const password = ref('')
const emptyCheck = ref(false)
const statusCode = ref(0)
const errText = ref('')
const activeClass = ref(false)
const className = ref('')
const payload = ref({})
onMounted(async () => {
    token.value = "Bearer " + $cookies.get("token")
    if(token.value !== null){
      payload.value = parseJwt($cookies.get("token"))
    }
    if(payload.value.role !== 'admin'){
      alert("ACCESS DENIED")
      router.back()
    }
})
const dataMatch  = async (token) =>{
  let user = {
    username : username.value.trim(),
    password : password.value.trim() ?? ''
  }
  try {
        const res = await fetch(FETCH_API + '/users/match',{
                    method : "POST",
                    headers: {
                      "Content-Type": "application/json",
                      'Authorization' : token

                    },
                    body: JSON.stringify(user)
                  })
        if(res.status === 200){
          statusCode.value = 200
          errText.value = 'Password Matched'
          activeClass.value = true
          className.value = 'alert-success'
        }else if(res.status === 404){
          statusCode.value = 404
          errText.value = 'The specified username DOES NOT exist'
          activeClass.value = true
          className.value = 'alert-error'
        }else if(res.status === 401){
          statusCode.value = 401
          errText.value = 'Password NOT Matched'
          activeClass.value = true
          className.value = 'alert-error'
        }
    } catch (error) {
        alert(error)
    }
}

</script>
 
<template>
   
    <div class="w-full mt-16">
        <div class="w-3/5 mt-4 relative m-auto">
        <div class=" mb-5 p-5 rounded-lg  div" style="line-height:50px">
            
            <div class="flex gap-1 items-center justify-start">
                <svg  class=" text-black mt-3 ml-2" width="30" height="30" xmlns="http://www.w3.org/2000/svg" ><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21L4 22l.99-3.95l5.43-5.44Z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5M4 13.5V6a2 2 0 0 1 2-2h2"/></g></svg>
                <h1 class=" font-bold font-serif text-black mt-3 ">Match Password </h1>
            </div>
            <hr class=" font-bold mb-5"/>
            <!-- Username -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 ">Username <span class="text-red-700">*</span></span>
                <input rows="5" type="text" placeholder="Type your username here..." class="ann-username  input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="45" v-on:keyup.enter="dataMatch(token)" v-model="username" required/>
            </label>

            <!-- Password -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4 ">Password <span class="text-red-700">*</span></span>
                <input rows="5" type="password" placeholder="Type your password here..." class="ann-password input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="14" v-on:keyup.enter="dataMatch(token)" v-model="password" required/>
            </label>     

            <!-- Warning Text -->
            <div :class="[ activeClass ? className : '', 'alert justify-start w-full h-12 mt-3 overflow-scroll overflow-x-hidden overflow-y-hidden']" v-if="activeClass">
                <successIcon v-if="statusCode===200"/>
                <errorIcon v-if="statusCode!==200"/>
                <span class="ann-message font-semibold">{{errText}}</span>
            </div>
            <div class="mt-3">
              <button @click="dataMatch(token)" class="ann-button btn buttonMatch" type="submit">Match or Not</button>
            </div>
            
        </div>
         <!-- Button -->    
            
           
        </div>
        
    </div>
</template>

<style scoped>
.buttonMatch{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255);  
}
.buttonMatch:hover{
    border:2px solid #5eb706;
    background-color: #5eb706;
  color: rgb(255, 255, 255); 
}
/* -------------------------------------------- */
.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}
body, html {
  padding: 0;
  margin: 0;
  width: 100%;
  min-height: 100vh;
}
body {
  background-color: #262626;
}


.Desc{
    border-radius: 15px;
    background-color: #ffffff;
    width: 60%;
}
hr {
  border: 1px solid rgb(255, 255, 255);
}

</style>