<script setup>
import {ref, onMounted } from 'vue';
import { useRoute ,useRouter } from 'vue-router'
import { formatDate } from '../composable/formatDate'
import { userAnnouncement } from '../stores/announcerStore'
const router = useRouter()
const { params } = useRoute()
const FETCH_API = import.meta.env.VITE_API
const announcementDetail = ref([])
const errorMSG = ref('')
const userAnn = userAnnouncement()
const isActive = ref()
const emit = defineEmits(['reloadUser'])

onMounted(async ()=>{
    isActive.value = userAnn.getMode()
    await loadDetail()
})



const loadDetail = async () =>{
    try {
        const res = await fetch(`${FETCH_API+'/announcements'}/${params.id}?count=true`)
        if(!res.ok){
            alert('The request page is not available')
            router.push({
                name : 'home'
            })
            throw new Error(res.status)
        }else{
            announcementDetail.value = await res.json()
        }
    }catch(err){
        errorMSG.value = err
    }
}

</script>

<template>
    
   <div id="app">
    <div class="w-full ">
        <h1 class="pt-5 ml-10 mb-3 font-bold text-white"> </h1>
        <div class=" ml-10 mr-20 mb-5  p-5 rounded-lg div   " style="line-height:50px">

                <div class="flex mt-1 ml-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="20" viewBox="0 0 256 256" class="mr-2 text-sky-600"><path fill="currentColor" d="M243.31 136L144 36.69A15.86 15.86 0 0 0 132.69 32H40a8 8 0 0 0-8 8v92.69A15.86 15.86 0 0 0 36.69 144L136 243.31a16 16 0 0 0 22.63 0l84.68-84.68a16 16 0 0 0 0-22.63Zm-96 96L48 132.69V48h84.69L232 147.31ZM96 84a12 12 0 1 1-12-12a12 12 0 0 1 12 12Z"/></svg>
                    <h1 class="ann-category text-sky-600 text-sm mr-5 font-bold mb-3"  >Category : <span class="ann-category text-slate-600">{{ announcementDetail.announcementCategory}}</span></h1>       
                    <svg v-if="!isActive" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 256 256" class="mr-2 text-red-600"><path fill="currentColor" d="M230 136.49A102.12 102.12 0 1 1 119.51 26a6 6 0 0 1 1 12A90.13 90.13 0 1 0 218 135.51a6 6 0 1 1 12 1ZM122 72v56a6 6 0 0 0 6 6h56a6 6 0 0 0 0-12h-50V72a6 6 0 0 0-12 0Zm38-26a10 10 0 1 0-10-10a10 10 0 0 0 10 10Zm36 24a10 10 0 1 0-10-10a10 10 0 0 0 10 10Zm24 36a10 10 0 1 0-10-10a10 10 0 0 0 10 10Z"/></svg>
                    <h1 class="ann-close-date text-red-600 text-sm mr-5 font-bold" v-if="!isActive" >CloseDate : <span class="ann-close-date text-slate-500" >{{ announcementDetail.closeDate === null || announcementDetail.closeDate === undefined ? '-' : formatDate(announcementDetail.closeDate) }}</span></h1> 
                </div>    
                <h1 class="ann-title font-bold text-2xl ml-5" >{{ announcementDetail.announcementTitle}}</h1>
             <div class="border-t-2 border-zinc-200 mr-20 line mt-3 mb-3 ml-5"></div>
             <div class="ann-description ml-5 overflow-y-auto ql-editor" v-html=" announcementDetail.announcementDescription"></div>
                <!-- <h1 class="ann-description " >{{ announcementDetail.announcementDescription}}</h1>         -->

        </div>
        <router-link to="/announcement"><button class="ann-button ml-10 mb-6 btn buttonBack ">Back</button></router-link>
        
   
    </div>
</div>
   

</template>

<style scoped>

.buttonBack{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255); 
}
.buttonBack:hover{
    border: 2px solid #037ebc;
    background-color: #037ebc;
  color: rgb(255, 255, 255); 
}

.line{
    border: 1px solid #f9ef9a;
}
/* ----------bg----------- */
.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}

</style>
