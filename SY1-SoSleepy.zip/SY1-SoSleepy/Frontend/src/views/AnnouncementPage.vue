<script setup>
import { ref, onMounted } from 'vue';
import { useRouter,useRoute } from 'vue-router'
import { formatDate } from '../composable/formatDate'
import { adminAnnouncement } from '../stores/adminStore'
import { parseJwt } from '../composable/getToken';
import { inject } from 'vue'

const $cookies = inject('$cookies')
const announcementData = ref({})
const announcements = ref({})
const errorMessage = ref()
const router = useRouter()
const FETCH_API = import.meta.env.VITE_API
const adminAnn = adminAnnouncement()
const categories = ref({})
const category = ref(0)
const pageSelected = ref()
const first = ref()
const totalPage = ref()
const last = ref()
const token = ref('')
const payload = ref({})
const emit = defineEmits(['reloadUser'])
onMounted(async () => {
    token.value = "Bearer " + $cookies.get("token")
  if(token.value !== null){
    payload.value = parseJwt($cookies.get("token"))
  }
  adminAnn.setCategory(category.value)
  pageSelected.value = adminAnn.getPage() === undefined ? 0 : adminAnn.getPage()
    await loadData(category.value, pageSelected.value,token.value)
    await loadCategory(token.value)
  
})
const loadData = async (catId, pageNumber,token) => {
  await fetch(`${FETCH_API + '/announcements'}/pages?mode=admin&category=${catId}&page=${pageNumber}&username=${payload.value.sub}`,{
    headers : {
      'Authorization' : token
    }
  })
    .then(res => res.json())
    .then(data => {
      announcementData.value = data
      if(payload.value.role === 'admin'){
        announcements.value = announcementData.value.content
      }else if(payload.value.role === 'announcer'){
        announcements.value = announcementData.value.content.filter(ann => ann.announcementOwner === payload.value.sub)
      }
      first.value = announcementData.value.first
      totalPage.value = announcementData.value.totalPages
      last.value = announcementData.value.last
    })
    .catch((err) => errorMessage.value = err)
}
const loadCategory = async (token) => {
  await fetch(FETCH_API + '/categories',{
    headers:{
      'Authorization': token
    }
  })
    .then(res => res.json())
    .then(data => categories.value = data)
    .catch((err) => errorMessage.value = err)
}
const countItems = (index) => {
  pageSelected.value = adminAnn.getPage() === undefined ? 0 : adminAnn.getPage()
  const numberPerPage = 5
  let item = index + 1
  let startNumber = ((pageSelected.value) * numberPerPage)
  return startNumber + item
}

const maxPage = () => {
  return announcementData.value.totalPages <= 10 ? announcementData.value.totalPages : 10
}

const pageRange = () => {
  let i = 1
  let range = []
  let max = pageSelected.value + 1 <= 10 ? maxPage() : pageSelected.value + 1
  for (i; i <= max; i++) {
    range.push(i)
  }

  if (pageSelected.value + 1 <= 10) {
    return range
  }
  return range.slice(-10)
}

const changePage = async (pageNumber) => {
  adminAnn.setPage(pageNumber)
  pageSelected.value = pageNumber
  await loadData(category.value, pageSelected.value, token.value)
}


const showDescription = (announcementId) => {
  router.push({
    name: 'desc',
    params: { id: announcementId }
  })
}

const deleteAnnouncement = async (announcementId) => {
  let result = confirm('Confirm to delete this announcement. Do you want to delete it?')
  if (result) {
    fetch(`${FETCH_API + '/announcements'}/${announcementId}`, {
      headers:{
        'Authorization': token.value
      },
      method: "DELETE"
    })
      .then(async () => {
        announcementData.value = await loadData(category.value, pageSelected.value,token.value)
        router.push("/admin/announcement")
      })
      .catch((err) => errorMessage.value = err)
  }
}


const changeCategory = async () => {
  pageSelected.value = 0
  adminAnn.setPage(pageSelected.value)
  adminAnn.setCategory(category.value)
  await loadData(category.value, pageSelected.value,token.value)
}

</script>
<template>
  <div class="w-full">
    <div class="flex flex-col space-y-5">
      <div class="w-full flex justify-center">
        <div class="lg:w-5/6 md:w-1/2 sm:w-4/5 min-w-max justify-between sm:flex sm:flex-col md:flex md:flex-row lg:flex lg:flex-row">
          <div class="flex flex-col min-w-fit w-1/2">
            <div class="flex w-full  mt-5 ml-5">
              <svg class="mr-3 text-amber-800" xmlns="http://www.w3.org/2000/svg" width="32" height="32"
                viewBox="0 0 24 24">
                <path fill="currentColor"
                  d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2zm-2 1H8v-6c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5v6zM7.58 4.08L6.15 2.65C3.75 4.48 2.17 7.3 2.03 10.5h2a8.445 8.445 0 0 1 3.55-6.42zm12.39 6.42h2c-.15-3.2-1.73-6.02-4.12-7.85l-1.42 1.43a8.495 8.495 0 0 1 3.54 6.42z" />
              </svg>
              <h1 class="font-semibold text-2xl text-end text-amber-600">Announcement</h1>
            </div>
            <div class="flex flex-col w-full mt-5 ml-5">
              <h3 class="text-lg font-semibold mt-2 mb-2 ml-3">Date/Time shown in Timezone : <span class="font-medium text-neutral-400">{{ Intl.DateTimeFormat().resolvedOptions().timeZone }}</span></h3>
              <label class="ml-3 mt-1  flex ">
                <span class="block text-sm font-medium text-slate-700 mr-3 mt-1  ">Choose Category :</span>
                <select name="category" class="ann-category rounded-md border p-1  " v-model="category"
                  @change="changeCategory">
                  <option :value="0">ทั้งหมด</option>
                  <option v-for="cat in categories" :value="cat.id">{{ cat.categoryName }}</option>
                </select>
              </label>
            </div>
          </div>

          <!-- Add User-->
          <div class="ml-3 justify-end flex mt-auto">
            <button @click="router.push('/admin/announcement/add')" class="ann-button mr-5 p-2 flex btnhead rounded-md mt-2">
              <svg xmlns="http://www.w3.org/2000/svg"  class="mt-1" width="20" height="20" viewBox="0 0 24 24"><path fill="currentColor" d="M20 14h-6v6h-4v-6H4v-4h6V4h4v6h6v4Z" /></svg>
              <h1 class="pl-2 mr-2 font-semibold">Add Announcement</h1>
            </button>
          </div>
        </div>
      </div>

      <div class="overflow-x-auto w-full justify-center flex">
      <table class="table table-zebra w-4/5 border-b-2 border-yellow-500 min-w-fit">
          <thead>
            <tr class="text-left">
              <th>No</th>
              <th>Title</th>
              <th>Category</th>
              <th>Publish Date</th>
              <th>Close Date</th>
              <th>Display</th>
              <th v-if="payload.role === 'admin'">Owner</th>
              <th>#Views</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr class="ann-item hover:border hover:border-black" v-for="announcement, index in announcements">
              <th>{{ countItems(index) }}</th>
              <td class="ann-title">{{ announcement.announcementTitle }}</td>
              <td class="ann-category">{{ announcement.announcementCategory }}</td>
              <td class="ann-publish-date">{{ announcement.publishDate === null ? '-' :
                formatDate(announcement.publishDate) }}</td>
              <td class="ann-close-date">{{ announcement.closeDate === null ? '-' : formatDate(announcement.closeDate) }}</td>
              <td class="ann-display">{{ announcement.announcementDisplay === "Y" ? "Yes" : "No" }}</td>
              <td class="ann-username" v-if="payload.role === 'admin'">{{ announcement.announcementOwner }}</td>
              <td class="ann-counter">{{ announcement.viewCount }}</td>
              <td class="space-x-2 justify-center">
                <button @click="showDescription(announcement.id)"
                  class="ann-button btn btn-outline  btn-info">view</button>
                <button @click="deleteAnnouncement(announcement.id)"
                  class="ann-button btn btn-outline btn-error">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <h3 v-if="announcements.length === 0" class="mt-3 text-center text-red-600 font-bold">No Announcement</h3>
      <img v-if="announcements.length === 0" src="https://i.gifer.com/XOsX.gif" alt="Computer man" style="width:60px;height:60px; margin-left: 48%;">
    </div>
  </div>
  <div class="pagination" v-if="Object(announcementData?.content).length !== 0 && announcementData?.totalPages > 1">
        <div class="btn-group">
          <button class="btn btn-sm btn-warning hover:border-black" :disabled="first"
            @click="changePage(pageSelected - 1)">&laquo; Prev</button>
          <button class="btn btn-sm hover:border-black"
            :class="pageSelected + 1 === page ? 'glass text-black' : 'btn-warning'" v-for="page in pageRange()"
            @click="changePage(--page)">{{ page }}</button>
          <button class="btn btn-sm hover:border-black"
            :class="pageSelected + 1 === pageSelected + 1 ? 'glass text-black' : 'btn-warning'"
            v-if="pageSelected + 1 > pageRange()">{{ pageSelected + 1 }}</button>
          <button class="btn btn-sm btn-warning hover:border-black" :disabled="last"
            @click="changePage(pageSelected + 1)">Next &raquo;</button>
        </div>
        <div class="text-center text-sm font-bold mt-2">
          <span>PAGE : {{ pageSelected + 1 }} of {{ totalPage }}</span>
        </div>
      </div>

</template>

<style>.buttonAdd {
  border: 1px solid #2c2c2c;
  background-color: #2c2c2c;
  color: rgb(255, 255, 255);
}

.buttonAdd:hover {
  border: 1px solid #55a92d;
  background-color: #55a92d;
  color: rgb(255, 255, 255);
}</style>
