<script setup >
import { ref, onMounted , computed } from 'vue';
import { useRouter,useRoute } from 'vue-router'
import { formatDate } from '../composable/formatDate'
import warningIcon from '../icons/warningIcon.vue'
import { parseJwt } from '../composable/getToken';
import { inject } from 'vue'
const $cookies = inject('$cookies')
const token = ref('')
const FETCH_API = import.meta.env.VITE_API
const { params } = useRoute()
//PAGE
const oldData = ref({})
const userData = ref({})
const roles = ["admin","announcer"]
const dataCheck = ref(false)
const requirement = ref('')
const router = useRouter()
const errorMessage = ref('')
const payload = ref({})
//VALIDATE
const emailBlock = ref(false)
const emailRegex = /^[^@]+@[^@]+\.[^.]{1,3}$/
const responseError = ref({})
const validateData = ref(false)
const usernameWarning = ref('')
const nameWarning = ref('')
const emailWarning = ref('')
//FUNCTION
onMounted(async ()=>{
  token.value = "Bearer " + $cookies.get("token")
  
  if(token.value !== null){
    payload.value = parseJwt($cookies.get("token"))
    if (payload.value.role !== 'admin') {
      alert("ACCESS DENIED")
      router.back()
    }
  }
  await loadData(token.value)
  oldData.value = {
    "username" : userData.value.username,
    "name" : userData.value.name,
    "email" : userData.value.email,
    "role" : userData.value.role
  }
})

const loadData = async (token) =>{
  await fetch(FETCH_API + '/users/' + params.id ,{
    headers : {
      'Authorization' : token
    }
  })
        .then(res => res.json())
        .then(data => userData.value = data)
        .catch(err => alert('Could not load data : ' + err))
}

const editedData = computed(()=>{
  if(String(userData.value.username).length === 0){
      dataCheck.value = true
      requirement.value = "Username cannot be empty!!!"
    }else if(String(userData.value.name).length === 0){
      dataCheck.value = true
      requirement.value = "Name cannot be empty!!!"
      
    }else if(String(userData.value.email).length === 0){
      dataCheck.value = true
      requirement.value = "Email cannot be empty!!!"
    }else{
      dataCheck.value = false
      requirement.value = ""
    }
  return {
    "username" : userData.value.username,
    "name" : userData.value.name,
    "email" : userData.value.email,
    "role" : userData.value.role
  }
})


const enableEdit = computed(()=>{
    let undefinedData = String(editedData.value.username).length === 0 || String(editedData.value.name).length === 0 || String(editedData.value.email).length === 0
    //Email pattern
    if(!emailRegex.test(userData.value.email)){
        emailBlock.value = true
    }else{
        emailBlock.value = false
    }
    return JSON.stringify(editedData.value) === JSON.stringify(oldData.value) || undefinedData || emailBlock.value
})

const cancel =()=>{
    let result = confirm('Confirm to cancel ')
    if(result)router.push({name : 'UserList'})
}
const submit = async (token)=>{
    // const result = confirm('The data will be changed!! Are you sure?')
    const username = String(editedData.value.username).trim()
    const name = String(editedData.value.name).trim()
    const email = String(editedData.value.email).trim()
    const role = String(editedData.value.role).trim()

    usernameWarning.value = ''
    nameWarning.value = ''
    emailWarning.value = ''

    const data = {
    "username" : username,
    "name" : name,
    "email" : email,
    "role" : role
    }
    
    if(JSON.stringify(data) === JSON.stringify(oldData.value)){
        router.push('/admin/user')
    }else{
      await fetch(FETCH_API + '/users/' + params.id,{
        method : 'PUT',
        headers : {
            "Authorization" : token,
            "Content-Type": "application/json"
        },
        body : JSON.stringify(data)
      })
      .then(async (res) => {
        if(res.ok){
            alert('Updated user successfully.')
            if(payload.value.sub === data.username){
              router.push('/admin/user')
            }else{
              alert("Your username was changed! Please relogin")
              $cookies.remove("token")
              $cookies.remove("refreshToken")
              router.push("/login")
            }
        }else{
            console.log(1);
            responseError.value = await res.json()
            if(responseError.value.status === 400){
                validateData.value = true
                for(const data of responseError.value.detail){
                    if(data.field === "username") usernameWarning.value = data.errorMessage
                    if(data.field === "name") nameWarning.value = data.errorMessage
                    if(data.field === "email") emailWarning.value = data.errorMessage
                }
            }
        }
      })
      .catch(err => errorMessage.value = err)
    }
    // if(result){
      
    // }else{
    //   router.push('/admin/user')
    // }
}
</script>
 
<template>

    
    <div class="w-full  mt-16">
      <div class="w-3/5 mt-4 relative m-auto">
        <form @submit.prevent="handleSubmit">
        <div class=" mb-5 p-5 rounded-lg  div" style="line-height:50px">

        <div class=" flex gap-1 items-center justify-start">
          <svg  class=" text-black mt-3 ml-2" width="30" height="30" xmlns="http://www.w3.org/2000/svg" ><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21L4 22l.99-3.95l5.43-5.44Z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5M4 13.5V6a2 2 0 0 1 2-2h2"/></g></svg>
            <h1 class=" font-bold font-serif text-black mt-3 ">Edit User </h1>
        </div>
        <hr class=" font-bold mb-5"/>

        <!-- <div class=" ml-10 mr-20 mb-5 p-5 rounded-lg  div" style="line-height:50px"> -->
            <!-- Username -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 ">Username <span class="text-red-700">*</span></span>
                <div class="flex">
                  <input rows="5" type="text" placeholder="Type your username here..." pattern="^(?!\s+$).+" oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')" class="ann-username  input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="45" v-model="userData.username" required/>
                  <div class="flex flex-row justify-between w-20">
                    <span class="text-sm font-medium text-slate-700 ml-2 mt-3">({{ String(userData.username).length }}/45)</span> 
                  </div>
                </div>
              </label>
              <!-- Warning for Username field -->
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && usernameWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-username">{{ usernameWarning }}</span>
            </div>

            <!-- Name -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4">Name <span class="text-red-700">*</span></span>
                <div class="flex">
                  <input rows="5" type="text" placeholder="Type your name here..." pattern="^(?!\s+$).+" oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')" class="ann-name  input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="100" v-model="userData.name" required/>
                  <div class="flex flex-row justify-between w-20">
                    <span class="text-sm font-medium text-slate-700 ml-2 mt-3">({{ String(userData.name).length }}/100)</span> 
                  </div>
                </div>
              </label>
              <!-- Warning for Name field -->  
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && nameWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-name">{{ nameWarning }}</span>
            </div>

            <!-- Email -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4 ">Email <span class="text-red-700">*</span></span>
                <div class="flex">
                  <input rows="5" type="text" placeholder="Type your email here..." pattern="^(?!\s+$).+" oninvalid="this.setCustomValidity('Please fill out this field.')" oninput="this.setCustomValidity('')" class="ann-email input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="150" v-model="userData.email" required/>
                  <div class="flex flex-row justify-between w-20">
                    <span class="text-sm font-medium text-slate-700 ml-2 mt-3">({{ String(userData.email).length }}/150)</span>
                  </div>
                </div>
            </label>
            <!-- Warning for Email field -->  
            <div class="flex gap-1 items-center justify-start text-red-600" v-if="validateData && emailWarning.length != 0">
                <warningIcon class="mt-2"/>
                <span class="font-serif text-sm mt-3 w-1/2 m-1 ann-error-email">{{ emailWarning }}</span>
            </div>

            <!-- Role -->
            <label class="block  mt-3 ">
                <span class="block text-sm font-medium text-slate-700  ">Role<span class="text-red-700">*</span></span>
                <select name="role" class="ann-role rounded-md border p-1 " v-model="userData.role">
                    <option v-for="role in roles" :value="role">{{ role }}</option>
                </select>
            </label>

            
            <!-- CreateOn and UpdateOn -->
            <div class="flex">
              <span class="block text-sm font-medium text-slate-700 mr-20 mt-2 ">Creates On : <span class="font-bold ann-created-on">{{ formatDate(userData.createdOn) }}</span> </span>
              <span class="block text-sm font-medium text-slate-700 mt-2 ">Updated On : <span class="font-bold ann-updated-on ">{{ formatDate(userData.updatedOn) }}</span></span>
            </div>

            <!-- Warning Text -->
            <div class="alert alert-error justify-start w-full  overflow-scroll overflow-x-hidden overflow-y-hidden mt-3" v-if="dataCheck">
                <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                <span class="font-semibold">Warning! {{ requirement }}</span>
            </div>
        </div>
         <!-- Button  -->    
            <button @click="submit(token)" class="ann-button btn buttonSubmit" type="submit" :disabled="enableEdit">Save</button>
            <button @click="cancel" class="ann-button ml-5 mb-6 btn buttonCancle" >Cancel</button>
        </form>
          </div>
      
    </div>
</template>

<style scoped>
.buttonSubmit{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255);  
}
.buttonSubmit:hover{
    border:2px solid #5eb706;
    background-color: #5eb706;
  color: rgb(255, 255, 255); 
}
/* -------------------------------------------- */
.buttonCancle{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255); 
}
.buttonCancle:hover{
    border: 2px solid #d43a1b;
    background-color: #d43a1b;
  color: rgb(255, 255, 255); 
}

.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}
body, html {
  padding: 0;
  margin: 0;
  width: 100%;
  min-height: 100vh;
}
body {
  background-color: #262626;
}


.Desc{
    border-radius: 15px;
    background-color: #ffffff;
    width: 60%;
}

</style>