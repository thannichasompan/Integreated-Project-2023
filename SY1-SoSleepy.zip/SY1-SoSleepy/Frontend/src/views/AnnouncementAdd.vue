<script setup >
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router'
import { inject } from 'vue'
const $cookies = inject('$cookies')
const token = ref('')
const FETCH_API = import.meta.env.VITE_API
//PAGE
const errorMessage = ref()
const router = useRouter()
const categories = ref({})
const displays = {
    yes : "Y",
    no  : "N"
}
const title = ref('')
const description = ref('')
const category = ref(1)
const publishDate = ref('')
const publishTime = ref('')
const closeDate = ref('')
const closeTime = ref('')
const display = ref(false)
const publishDateTime = ref('')
const closeDateTime = ref('')
const validData = ref(false)
const announcementObj = ref({})


//FUNCTION
onMounted(async ()=>{
    token.value = "Bearer " + $cookies.get("token")
    await loadCategory(token.value)
})
const loadCategory = async (token) =>{
    await fetch(FETCH_API+'/categories',{
    headers:{
      'Authorization': token
    }
  })
    .then(res => res.json())
    .then(data => categories.value = data)
    .catch((err) => errorMessage.value = err)
}

const cancel =()=>{
    let result = confirm('Confirm to cancel ')
    if(result)router.push({name : 'home'})
}

const submit = async (token)=>{
    publishDateTime.value = null
    closeDateTime.value = null
    if(title.value === undefined || title.value.length === 0){
        title.value = null
        validData.value = false
        alert('Title could not be empty!!!')
    }else if((title.value !== undefined || title.value.length !== 0) && (description.value === undefined || description.value.length === 0)){
        title.value = null
        validData.value = false
        alert('Description could not be empty!!!')
    }else{
        validData.value = true
    }
    if(publishDate.value !== "" && publishTime.value !== ""){
        publishDateTime.value = new Date(`${publishDate.value}T${publishTime.value}`).toISOString()
    }else if(publishDate.value !== "" && publishTime.value === ""){
        publishDateTime.value = new Date(`${publishDate.value}T06:00`).toISOString()
    }
    if(closeDate.value !== "" && closeTime.value !== ""){
        closeDateTime.value = new Date(`${closeDate.value}T${closeTime.value}`).toISOString()
    }else if(closeDate.value !== "" && closeTime.value === ""){
        closeDateTime.value = new Date(`${closeDate.value}T18:00`).toISOString()
    }
    display.value ? display.value = displays.yes : display.value = displays.no
     
    announcementObj.value = {
        "announcementTitle" : title.value,
        "announcementDescription"   : description.value,
        "publishDate"   : publishDateTime.value,
        "closeDate" : closeDateTime.value,
        "announcementDisplay"   : display.value,
        "categoryId"  : category.value
    }
    if(validData.value){
        try {
            const res = await fetch(FETCH_API+'/announcements',{
                        method: "POST",      
                        headers: {
                            "Content-Type": "application/json",
                            'Authorization': token
                        },
                        body: JSON.stringify(announcementObj.value)
                    })
            if(res.status === 200){
                const response = await res.json()
                router.push('/admin/announcement')
            }else{
                alert('Could not create announcement!')
                router.push('/admin/announcement/add')
            }
        } catch (error) {
            alert(error)
        }
    }else{
            alert('Could not create announcement!')
        }
}

</script>
 
<template>

<div class="w-full mt-16">
    <div class="w-3/5 mt-4 relative m-auto">
    <div class=" mb-5 p-5 rounded-lg  div" style="line-height:50px">
            
    <div class="flex gap-1 items-center justify-start">
        <svg  class=" text-black mt-3 ml-2" width="30" height="30" xmlns="http://www.w3.org/2000/svg" ><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21L4 22l.99-3.95l5.43-5.44Z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5M4 13.5V6a2 2 0 0 1 2-2h2"/></g></svg>
        <h1 class=" font-bold font-serif text-black mt-3 ">Add Announcement </h1>
    </div>

    <hr class=" font-bold mb-5"/>

    <div class="w-full  ">
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 ">Title <span class="text-red-700">*</span></span>
                <input rows="5" type="text" placeholder="Type your title here..." class="ann-title input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="200" v-model="title" required/>
                <span class="text-sm font-medium text-slate-700 ml-2">({{ title.trim().length }}/200)</span> <br>
                <span class="text-red-700 font-bold text-sm" v-if="title.length === 0">** The length of <b>[ Title ]</b> must be between 0 and 200</span>
            </label>
            <!-- Category -->
             <label class="block  mt-3 ">
                <span class="block text-sm font-medium text-slate-700  ">Category <span class="text-red-700">*</span></span>
                <select name="category" class="ann-category rounded-md border p-1" v-model="category">
                    <!-- <option :value="undefined" disabled>--Please choose category--</option> -->
                    <option v-for="cat in categories" :value="cat.id">{{ cat.categoryName }}</option>
                </select>
            </label>
            <!-- Description -->
            <label class="block mt-3 ">
                <span class="block text-sm font-medium text-slate-700  mb-2">Description <span class="text-red-700">*</span></span>
                <div class=" Desc  ">
                    <quill-editor 
                        class="ann-description "
                        theme="snow" 
                        toolbar="full"
                        v-model:content="description"
                        contentType="html"> 
                    </quill-editor>      
                </div> 
                    <span class="text-sm font-medium text-slate-700 ml-2">({{ description.length }}/10000)</span> <br>
                    <span class="text-red-700 font-bold text-sm" v-if="description.length === 0">** The length of <b>[ Description ]</b> must be between 0 and 10,000</span>
            </label>
                            
            <!-- Publish Date -->
            <label class="block ">
                <span class="block text-sm font-medium text-slate-700  mb-2 ">Publish Date</span>
                <input type="date" class="ann-publish-date pl-3 pr-5 h-10 border rounded-md mr-5 mb-3" v-model="publishDate"><span class="font-bold">>></span>
                <input type="time" class="ann-publish-time border rounded-md pl-5 pr-5 h-10 ml-5" v-model="publishTime" :disabled="publishDate === ''">
            </label>  
           <!-- Close Date -->
           <label class="block ">
                <span class="block text-sm font-medium text-slate-700  mb-2 ">Close Date</span>
                <input type="date" class="ann-close-date pl-3 pr-5 h-10 border rounded-md mr-5 mb-3" v-model="closeDate"><span class="font-bold">>></span>
                <input class="ann-close-time border rounded-md pl-5 pr-5 h-10 ml-5" type="time" v-model="closeTime" :disabled="closeDate === ''">
            </label>  
           <!-- Display -->
            <label class="block ">
                <span class="block text-sm font-medium text-slate-700 ">Display</span>
                <input type="checkbox" class="ann-display checkbox-xs" @click="display = !display" v-model="display"/>
                <span class=" text-sm  ml-3 ">Check to show this announcement</span>
            </label>    
                <span class="text-red-700 font-bold text-sm" v-if="description.length > 10000">** The length of <b>Description</b> must be between 0 and 10,000</span>
           <!-- Button -->
    
        
</div>
        </div>
            <button @click="submit(token)" class="ann-button btn buttonSubmit" type="submit" :disabled="description.length > 10000 || title.length <= 0 || description.length <= 0">Submit</button>
            <button @click="cancel" class="ann-button ml-5 mb-6 btn buttonCancle" >Cancel</button>
        </div>
        <!-- :disabled="description.length > 10000 -->
</div>
</template>

<style scoped>
.buttonSubmit{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255);  
}
.buttonSubmit:hover{
    border:2px solid #5eb706;
    background-color: #5eb706;
  color: rgb(255, 255, 255); 
}
/* -------------------------------------------- */
.buttonCancle{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255); 
}
.buttonCancle:hover{
    border: 2px solid #d43a1b;
    background-color: #d43a1b;
  color: rgb(255, 255, 255); 
}

.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}
body, html {
  padding: 0;
  margin: 0;
  width: 100%;
  min-height: 100vh;
}
body {
  background-color: #262626;
}


.Desc{
    border-radius: 15px;
    background-color: #ffffff;
    width: 60%;
}

</style>