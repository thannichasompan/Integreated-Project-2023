<script setup>
import { ref, onMounted, computed,createApp } from 'vue';
import { useRoute ,useRouter } from 'vue-router'
import { convertDate, convertTime } from '../composable/formatDate.js'
import { inject } from 'vue'
const $cookies = inject('$cookies')
const token = ref('')
const FETCH_API = import.meta.env.VITE_API
const { params } = useRoute()
let announcementDetail = ref({})
let old = ref()
let pDate = ref('')
let pTime = ref('')
let cDate = ref('')
let cTime = ref('')
let display = ref()
let displayStr = ref()
const errorMSG = ref()
const router = useRouter()
const categories = ref({})
const displays = {
    yes : "Y",
    no  : "N"
}

onMounted(async ()=>{
    token.value = "Bearer " + $cookies.get("token")
    await loadDetail(token.value)
    await loadCategory(token.value)
    if(announcementDetail.value.publishDate !== null){
        pDate.value = convertDate(announcementDetail.value.publishDate)
        pTime.value = convertTime(announcementDetail.value.publishDate)
    }
    if(announcementDetail.value.closeDate !== null){
        cDate.value = convertDate(announcementDetail.value.closeDate)
        cTime.value = convertTime(announcementDetail.value.closeDate)
    }
    display.value = announcementDetail.value.announcementDisplay === "Y"
    old.value = {
        "announcementTitle": announcementDetail.value.announcementTitle,
        "announcementDescription": announcementDetail.value.announcementDescription,
        "publishDate": pDate.value,
        "publishTime" : pTime.value,
        "closeDate": cDate.value,
        "closeTime": cTime.value,
        "announcementDisplay": display.value,
        "categoryId": announcementDetail.value.categoryId
    }
})

const enableEdit = computed(()=>{
    return JSON.stringify(editAnnouncement.value) === JSON.stringify(old.value) 
})

const editAnnouncement = computed(()=>{
    return {
        "announcementTitle": announcementDetail.value.announcementTitle,
        "announcementDescription": announcementDetail.value.announcementDescription,
        "publishDate": pDate.value,
        "publishTime" : pTime.value,
        "closeDate": cDate.value,
        "closeTime": cTime.value,
        "announcementDisplay": display.value,
        "categoryId": announcementDetail.value.categoryId
    }
})

const loadDetail = async (token) =>{
    return await fetch(`${FETCH_API+'/announcements'}/catId/${params.id}`,{
    headers:{
      'Authorization': token
    }
  })
    .then(res => {
        if(!res.ok){
            alert('The request page is not available')
            router.push({
                name : 'home'
            })
            throw new Error(res.status)
        }else{
            return res.json()
        }
    })
    .then(data => announcementDetail.value = data)
    .catch((err)=> errorMSG.value = err)
}
const loadCategory = async (token) =>{
    await fetch(FETCH_API+'/categories',{
    headers:{
      'Authorization': token
    }
  })
    .then(res => res.json())
    .then(data => categories.value = data)
    .catch((err) => errorMSG.value = err)
}

const cancel =()=>{
    confirm('Confirm to leave ')
    router.push({name : 'home'})
}

const submit = async (token) =>{
    let publishDateTime = null
    let closeDateTime = null
    displayStr.value = editAnnouncement.value.announcementDisplay ? displays.yes : displays.no
    if(announcementDetail.value.announcementTitle === undefined || announcementDetail.value.announcementTitle.length === 0){
        announcementDetail.value.announcementTitle = null
        alert('Title could not be empty!!!')
    }
    if(announcementDetail.value.announcementDescription === undefined || announcementDetail.value.announcementDescription.length === 0){
        announcementDetail.value.announcementTitle = null
        alert('Description could not be empty!!!')
    }
    if(editAnnouncement.value.publishDate !== "" && editAnnouncement.value.publishTime !== ""){
        publishDateTime = new Date(`${editAnnouncement.value.publishDate}T${editAnnouncement.value.publishTime}`).toISOString().split('.')[0]+"Z"
    }else if(editAnnouncement.value.publishDate !== "" && editAnnouncement.value.publishTime === ""){
        publishDateTime = new Date(`${editAnnouncement.value.publishDate}T06:00`).toISOString().split('.')[0]+"Z"
    }
    if(editAnnouncement.value.closeDate !== "" && editAnnouncement.value.closeTime !== ""){
        closeDateTime = new Date(`${editAnnouncement.value.closeDate}T${editAnnouncement.value.closeTime}`).toISOString().split('.')[0]+"Z"
    }else if(editAnnouncement.value.closeDate !== "" && editAnnouncement.value.closeTime === ""){
        closeDateTime = new Date(`${editAnnouncement.value.closeDate}T18:00`).toISOString().split('.')[0]+"Z"
    }
        try {
            const res = await fetch(`${FETCH_API+'/announcements'}/${params.id}`,{
                        method: "PUT",
                        headers: {
                            "Content-Type": "application/json",
                            'Authorization' : token
                        },
                        body: JSON.stringify({
                                    "announcementTitle": editAnnouncement.value.announcementTitle,
                                    "announcementDescription": editAnnouncement.value.announcementDescription,
                                    "publishDate": publishDateTime,
                                    "closeDate": closeDateTime,
                                    "announcementDisplay": displayStr.value,
                                    "categoryId": editAnnouncement.value.categoryId
                                })
                    })
            if(res.status === 200){
                const response = await res.json()
                router.push('/admin/announcement')
            }else{
                alert('Could not edit announcement!')
                router.push('/admin/announcement')
            }
        } catch (error) {
            alert(error)
        }
}

</script>
 
<template>
   <div class="w-full mt-16">
    <div class="w-3/5 mt-4 relative m-auto">
    <div class=" mb-5 p-5 rounded-lg  div" style="line-height:50px">
            
    <div class="flex gap-1 items-center justify-start">
        <svg  class=" text-black mt-3 ml-2" width="30" height="30" xmlns="http://www.w3.org/2000/svg" ><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21L4 22l.99-3.95l5.43-5.44Z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5M4 13.5V6a2 2 0 0 1 2-2h2"/></g></svg>
        <h1 class=" font-bold font-serif text-black mt-3 ">Edit Announcement </h1>
    </div>

    <hr class=" font-bold mb-5"/>

    <div class="w-full  ">
            <!-- Title -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2">Title</span>
                <input rows="5" type="text" placeholder="Type your title here..." class="ann-title input input-bordered textarea-md  w-3/5 max-w-xs" maxlength="200" v-model="announcementDetail.announcementTitle" />
                <span class="text-sm font-medium text-slate-700 ml-2">({{  String(announcementDetail.announcementTitle).length }}/200)</span>
            </label>
            <!-- Category -->
            <label class="block  mt-3 ">
                <span class="block text-sm font-medium text-slate-700  ">Category <span class="text-red-700">*</span></span>
                <select name="category" class="ann-category rounded-md border p-1" v-model="announcementDetail.categoryId">
                    <option v-for="cat in categories" :value="cat.id">{{ cat.categoryName }}</option>
                </select>
            </label>
            <!-- Description -->
            <label class="block  mt-3 ">
                <span class="block text-sm font-medium text-slate-700  mb-2">Description</span>

                <div class=" Desc  ">
                    <quill-editor 
                        class="ann-description "
                        theme="snow" 
                        toolbar="full"
                        v-model:content="announcementDetail.announcementDescription"
                        contentType="html"> 
                    </quill-editor>      
                </div> 
                <span class="text-sm font-medium text-slate-700 ml-2">({{  String(announcementDetail.announcementDescription).length }}/10000)</span>
            </label>
          
                
            <!-- Publish Date -->
            <label class="block ">
               <span class="block text-sm font-medium text-slate-700   ml-1 mt-1 ">Publish Date</span>
                
                    <input type="date" class="ann-publish-date pl-3 pr-5 h-10 border rounded-md mr-5 mb-3" v-model="pDate"><span class="font-bold">>></span>
                    <input type="time" class="ann-publish-time border rounded-md pl-5 pr-5 h-10 ml-5" v-model="pTime" :disabled="pDate === ''"> 
            </label>  
           <!-- Close Date -->
           <label class="block ">
                <span class="block text-sm font-medium text-slate-700   ml-1 mt-1">Close Date</span>
              
                <input type="date" class="ann-close-date pl-3 pr-5 h-10 border rounded-md mr-5 mb-3" v-model="cDate"><span class="font-bold">>></span>
                <input type="time" class="ann-close-time border rounded-md pl-5 pr-5 h-10 ml-5" v-model="cTime" :disabled="cDate === ''">
            </label>
           <!-- Display -->
            <label class="block ">
                <span class="block text-sm font-medium text-slate-700 ">Display</span>
                <input type="checkbox" class="ann-display checkbox-xs" @click="display = !display" v-model="display"/>
                <span class=" text-sm  ml-3 ">Check to show this announcement</span>
            </label>
          
</div>
</div> 
 <!-- Button -->   
        <button @click="submit(token)" class="ann-button btn buttonEdit" :disabled="enableEdit">Edit</button>
        <button @click="cancel" class="ann-button ml-5 mb-6 btn buttonCancle" >Cancle</button>
    </div>
</div>

</template>

<style scoped>
.buttonEdit{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255);  
}
.buttonEdit:hover{
    border:2px solid #5eb706;
    background-color: #5eb706;
  color: rgb(255, 255, 255); 
}
/* -------------------------------------------- */
.buttonCancle{
    border: 2px solid #fdfdfd;
    background-color: #262626;
  color: rgb(255, 255, 255);  
}
.buttonCancle:hover{
    border: 2px solid #d43a1b;
    background-color: #d43a1b;
  color: rgb(255, 255, 255); 
}

.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}
body, html {
  padding: 0;
  margin: 0;
  width: 100%;
  min-height: 100vh;
}
body {
  background-color: #262626;
}

.Desc{
    border-radius: 15px;
    background-color: #ffffff;
    width: 60%;
}

</style>