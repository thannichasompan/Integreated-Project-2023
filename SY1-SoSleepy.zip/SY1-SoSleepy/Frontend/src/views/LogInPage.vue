<script setup >
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import errorIcon from '../icons/errorIcon.vue'
import successIcon from '../icons/successIcon.vue'
import { inject } from 'vue'
const $cookies = inject('$cookies')
const FETCH_API = import.meta.env.VITE_API
const router = useRouter()
const username = ref('')
const password = ref('')
const statusCode = ref(0)
const errText = ref('')
const activeClass = ref(false)
const className = ref('')
const tokenExp = Number(import.meta.env.VITE_TOKEN_EXP)
const refresTokenExp = Number(import.meta.env.VITE_REFRESHTOKEN_EXP)
const hover = ref(true)
const emit = defineEmits(['reloadUser'])
const login = async () =>{
  let user = {
    username : username.value.trim(),
    password : password.value.trim() ?? ''
  }
  try {
        const res = await fetch(FETCH_API + '/token',{
                    method : "POST",
                    headers: {
                      "Content-Type": "application/json"
                    },
                    body: JSON.stringify(user)
                  })
        if(res.status === 200){
          statusCode.value = 200
          errText.value = 'Login Successfully'
          activeClass.value = true
          className.value = 'alert-success'

          const data = await res.json()
          $cookies.set("token",data.token,tokenExp)
          $cookies.set("refreshToken",data.refreshToken,refresTokenExp)
          emit('reloadUser',1)
          router.push("/admin/announcement")
        }else if(res.status === 404){
          statusCode.value = 404
          errText.value = 'A user with the specified username DOES NOT exist'
          activeClass.value = true
          className.value = 'alert-error'
        }else if(res.status === 401){
          statusCode.value = 401
          errText.value = 'Password Incorrect'
          activeClass.value = true
          className.value = 'alert-error'
        }
    } catch (error) {
        alert(error)
    }
}

const homepage = () =>{
  router.push("/announcement")
}
</script>
 
<template>
  <div class="w-full">
      <div class="min-w-fit md:w-3/6 sm:w-2/6 lg:w-2/6 absolute -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2">
        <div class=" mb-5 p-5 rounded-lg  div" style="line-height:50px">
           
            <div class="flex gap-1 items-center justify-center mb-3 mt-3 drop-shadow-md ">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="text-white" viewBox="0 0 256 256"><path fill="currentColor" d="M128 112a28 28 0 0 0-8 54.83V184a8 8 0 0 0 16 0v-17.17a28 28 0 0 0-8-54.83Zm0 40a12 12 0 1 1 12-12a12 12 0 0 1-12 12Zm80-72h-32V56a48 48 0 0 0-96 0v24H48a16 16 0 0 0-16 16v112a16 16 0 0 0 16 16h160a16 16 0 0 0 16-16V96a16 16 0 0 0-16-16ZM96 56a32 32 0 0 1 64 0v24H96Zm112 152H48V96h160v112Z"/></svg>
                <h3 class="text-2xl text-white font-medium " >Login </h3>
            </div>
            
            <!-- Username -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 ">Username <span class="text-red-700">*</span></span>
                <input rows="5" type="text" placeholder="Username..." class="ann-username  input input-bordered textarea-md " maxlength="45" v-model="username" v-on:keyup.enter="login" required/>
            </label>

            <!-- Password -->
            <label class="block">
                <span class="block text-sm font-medium text-slate-700 mb-2 mt-4 ">Password <span class="text-red-700">*</span></span>
                <input rows="5" type="password" placeholder="Password..." class="ann-password input input-bordered textarea-md " maxlength="14" v-model="password" v-on:keyup.enter="login" required/>
            </label>     

            <!-- Warning Text -->
            <div :class="[ activeClass ? className : '', 'alert justify-start w-full h-12 mt-3 overflow-scroll overflow-x-hidden overflow-y-hidden']" v-if="activeClass">
                <successIcon v-if="statusCode===200"/>
                <errorIcon v-if="statusCode!==200"/>
                <span class="ann-message font-semibold">{{errText}}</span>
            </div>
            
            <!-- Button -->  
            <div class="mt-3 space-x-3 flex flex-col">
              <button @click="login"  class="ann-button btn loginBtu " type="submit">login</button>
              <a href="" @click="homepage" class="btn btn-ghost btn-circle" @mouseover="hover = false" @mouseleave="hover = true">
                <svg class="text-blue-700" @mouseover="hover = false" @mouseleave="hover = true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 256 256"><path fill="currentColor" d="m221.56 100.85l-79.95-75.47l-.16-.15a19.93 19.93 0 0 0-26.91 0l-.17.15l-79.93 75.47a20.07 20.07 0 0 0-6.44 14.7V208a20 20 0 0 0 20 20h48a20 20 0 0 0 20-20v-44h24v44a20 20 0 0 0 20 20h48a20 20 0 0 0 20-20v-92.45a20.07 20.07 0 0 0-6.44-14.7ZM204 204h-40v-44a20 20 0 0 0-20-20h-32a20 20 0 0 0-20 20v44H52v-86.72l76-71.75l76 71.75Z"></path></svg>
                <span class="text-xs font-semibold text-blue-700" :class="[hover?'visible':'hidden']">Home</span>
              </a>
            </div>
            
        </div>
      </div>
  </div>
</template>

<style scoped>

input {
  width: 100%;
}
.div{
    background: linear-gradient( 70deg,#f7ce4a, #fda430, #ff8d2f );
}
body, html {
  padding: 0;
  margin: 0;
  width: 100%;
  min-height: 100vh;
}
body {
  background-color: #262626;
}



hr {
  border: 1px solid rgb(255, 255, 255);
}
.loginBtu{
    margin-top: 20px;
    margin-left: 25%;
    width: 50%;
    padding: 15px ;

    font-size: 16px;
    font-weight: 600;
    border-radius: 10px;
    cursor: pointer;
    color: #ffffff;
    background-color: #575757;
}

.loginBtu:hover{
    margin-top: 20px;
    margin-left: 25%;
    width: 50%;
    padding: 15px ;

    font-size: 16px;
    font-weight: 600;
    border-radius: 10px;
    cursor: pointer;
    color: #ffffff;
    background-color: #49c65c;
    border-color: #49c65c;
}
</style>


