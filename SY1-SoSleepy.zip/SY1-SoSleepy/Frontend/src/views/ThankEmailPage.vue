<script setup>
import { useRouter } from 'vue-router'
import { inject } from 'vue'
const router =  useRouter()
const $cookies = inject('$cookies')

const homePage =()=>{
    if($cookies.get("token") !== null){
        router.push('/admin/announcement')
    }
    else{
        router.push('/announcement')
    }
  }

</script>
 
<template>

<div class="w-full absolute flex " style="margin-left: 20%;">
    <section>
        <div class="container flex items-center min-h-screen px-6 py-12 mx-auto">
            <div>
                <h1 class="mt-3 text-2xl font-semibold text-gray-800 md:text-3xl">Thank you for Subscribe</h1>
                <div class="flex items-center mt-6 gap-x-3">
                        <button @click="homePage" class="flex items-center justify-center w-1/2 px-5 py-2 text-sm text-gray-700 transition-colors duration-200 bg-white border rounded-lg gap-x-2 sm:w-auto dark:hover:bg-gray-800 dark:bg-gray-900 hover:bg-gray-100 dark:text-gray-200 dark:border-gray-700">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 rtl:rotate-180">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18" />
                            </svg>
                            <span>Home</span>
                        </button> 
                </div>
            </div>
        </div>

    </section>
  <img class="w-1/6 h-1/6 mt-56 flex ml-10" src="https://i.gifer.com/XOsX.gif" alt="Computer man" >
  
</div>

</template>
 
<style scoped>

</style>