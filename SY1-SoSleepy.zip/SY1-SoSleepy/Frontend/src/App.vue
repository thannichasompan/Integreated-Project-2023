<script setup>
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css';
import { RouterView } from 'vue-router'
import Navbar from './components/Navbar.vue'
import { ref } from "vue"
const key = ref(0)
const update = (num) =>{
  key.value+=num
}

</script>

<template>
  <div class="w-full ">
    <Navbar :key="key"/>
    <router-view @reloadUser="update"></router-view>
  </div>
  
</template>

<style scoped>

</style>
