import { defineStore, acceptHMRUpdate } from "pinia";
import { ref } from "vue";
export const adminAnnouncement = defineStore('adminAnnouncement',()=>{

    //category
    const category = ref()
    const setCategory = (categoryId) => category.value = categoryId
    const getCategory = () => category.value

    const page = ref()
    const setPage = (pageNumber) => page.value = pageNumber
    const getPage = () => page.value
    return { setCategory, getCategory, setPage, getPage} 

})
if(import.meta.hot) import.meta.hot.accept(acceptHMRUpdate(adminAnnouncement, import.meta.hot))