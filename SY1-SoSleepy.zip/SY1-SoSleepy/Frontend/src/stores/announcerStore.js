import { defineStore, acceptHMRUpdate } from "pinia";
import { ref } from "vue";
export const userAnnouncement = defineStore('userAnnouncement',()=>{
    //mode
    const mode = ref(true)
    const setMode = () => mode.value = !mode.value
    const getMode = () => mode.value

    //category
    const category = ref()
    const setCategory = (categoryId) => category.value = categoryId
    const getCategory = () => category.value

    //page
    const page = ref()
    const setPage = (pageNumber) => page.value = pageNumber
    const getPage = () => page.value

    return { setMode , getMode, setCategory, getCategory, setPage, getPage} 

})
if(import.meta.hot) import.meta.hot.accept(acceptHMRUpdate(userAnnouncement, import.meta.hot))