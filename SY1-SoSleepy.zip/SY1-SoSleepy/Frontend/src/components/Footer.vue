<script setup>

</script>
 
<template>
    <div class="w-full">
      <footer class="footer footer-center p-4 bg-base-300 text-base-content absolute inset-x-0 bottom-0">
        <aside>
            <!-- Copyright © 2023 -->
            <p>School of Information Technology, King Mongkut's University of Technology Thonburi</p>
        </aside>
     </footer>  
    </div>
    
</template>
 
<style scoped>

</style>