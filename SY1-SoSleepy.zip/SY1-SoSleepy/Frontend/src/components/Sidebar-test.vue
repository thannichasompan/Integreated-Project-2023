<script setup>


function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}

</script>
 

<template>
  
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">  

<!-- Sidebar -->
<div class="w3-sidebar w3-bar-block w3-border-right sidebar" style="display:none" id="mySidebar">
  <button @click="w3_close()" class="w3-bar-item w3-large">Close &times;</button>
  
  <a href="#" class="w3-bar-item w3-button">Announcement</a>
  <a href="#" class="w3-bar-item w3-button">User</a>
  
</div>

<!-- Page Content -->

  <div>
<ul>
  <li><button class="burger  h-16 w-16" @click="w3_open()">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none"  class="inline-block w-5 h-5 stroke-current mt-2 mb-2 mr-2 "><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
      </button>
  </li>
  <li><h1 class=" normal-case text-xl mt-1 pt-4 pl-4 font-medium">SIT Announcement System (SAS)</h1></li>
  <li></li>
  <li style="float:right"><a class="active text-xl mt-1 admin " >
  </a></li>
</ul>
</div>

<div class="w3-sidebar w3-bar-block w3-border-right" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-large">Close &times;</button>
  <a href="#" class="w3-bar-item w3-button">Link 1</a>
  <a href="#" class="w3-bar-item w3-button">Link 2</a>
  <a href="#" class="w3-bar-item w3-button">Link 3</a>
</div>

 
</template>
 
<style scoped>
.shadow {
  box-shadow: -1px 5px 7px 1px rgba(0, 0, 0, 0.68);
  -webkit-box-shadow: -1px 5px 7px 1px rgba(0, 0, 0, 0.68);
  -moz-box-shadow: -1px 5px 7px 1px rgba(0, 0, 0, 0.68);
  background: #ffae36
}

.burger {
  color: #111;
  background: #f76d17
}

.burger:hover {
  background-color: #2c2c2c;
  color: rgb(255, 255, 255);
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #fea837;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {

  background-color: #fea837;
}

.admin {
  color: #111;
}


/* sidebar */


</style>