<script setup>
import { useRouter } from 'vue-router'
const router = useRouter()
</script>
 
<template>
  <div class="flex">
    <ul class="w-full">
      <li><h1 class=" normal-case text-xl mt-1 p-4 font-medium">SIT Announcement System (SAS)</h1></li>
      <li style="float:right"><a class="active text-xl mt-1 admin "></a></li>
    </ul>
  </div>
</template>
 


<style scoped>
.shadow {
  box-shadow: -1px 5px 7px 1px rgba(0, 0, 0, 0.68);
  -webkit-box-shadow: -1px 5px 7px 1px rgba(0, 0, 0, 0.68);
  -moz-box-shadow: -1px 5px 7px 1px rgba(0, 0, 0, 0.68);
  background: #ffae36
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #fea837;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {

  background-color: #fea837;
}

.admin {
  color: #111;
}

</style>
