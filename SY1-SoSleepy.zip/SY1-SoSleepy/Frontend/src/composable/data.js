
const loadData = async (url) =>{
    try {
      const res = await fetch(url)
      if(res.ok){
        const result = await res.json()
        return result
      }else{
        throw new Error('could not load data')
      }
    } catch (error) {
      alert(error)
    }
  }
  export { loadData }