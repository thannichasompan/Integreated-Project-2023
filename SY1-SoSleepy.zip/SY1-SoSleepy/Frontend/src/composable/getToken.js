import router from '../router'
import { Buffer } from "buffer";
const FETCH_API = import.meta.env.VITE_API
const getNewToken = async (refreshToken) =>{
  try{
    const res = await fetch(`${FETCH_API+'/token'}`,{
      headers:{
        'Authorization' : "Bearer " + refreshToken
      }
    })
    if(res.ok){
      const data = await res.json()
      return data.token
    }else{
      alert("Please Login")
      router.push("/login")
    }
  }catch(err){
      throw new Error(err)
  }
}

const parseJwt = (token) =>{
    return JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString())
}
  export { getNewToken, parseJwt }