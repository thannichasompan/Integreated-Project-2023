import { createRouter, createWebHistory } from 'vue-router'
import AnnouncementPage from '../views/AnnouncementPage.vue'
import AnnouncementView from '../views/AnnouncementView.vue'
import AnnouncementAdd from '../views/AnnouncementAdd.vue'
import AnnouncementEdit from '../views/AnnouncementEdit.vue'
import UserViewPage from '../views/UserViewPage.vue'
import UserViewDetail from '../views/UserViewDetail.vue'
import LogInPage from '../views/LogInPage.vue'
import UserListPage from '../views/UserListPage.vue'
import UserAddPage from '../views/UserAddPage.vue'
import UserEditPage from '../views/UserEditPage.vue'
import NotFound from '../views/PageNotFound.vue'
import MatchPage from '../views/MatchPage.vue'
import ThankEmailPage from '../views/ThankEmailPage.vue'
import { app } from '../main'
import { getNewToken } from '../composable/getToken'

const tokenExp = Number(import.meta.env.VITE_TOKEN_EXP)

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/admin/announcement',
      name: 'home',
      component: AnnouncementPage
    },
    {
      path: '/admin/announcement/:id(\\d+)',
      name: 'desc',
      component: AnnouncementView
    },
    {
      path: '/admin/announcement/add',
      name: 'form',
      component: AnnouncementAdd
    },
    {
      path: '/admin/announcement/:id(\\d+)/edit',
      name: 'edit',
      component: AnnouncementEdit
    },
    {
      path : '/announcement',
      name : 'userhome',
      component : UserViewPage
    },
    {
      path : '/announcement/:id(\\d+)',
      name : 'userDesc',
      component : UserViewDetail
    },
    
    // USER MANAGEMENT
    {
      path : '/login',
      name : 'login',
      component : LogInPage
    },
    {
      path: '/admin/user',
      name: 'UserList',
      component: UserListPage
    },
    {
      path: '/admin/user/add',
      name: 'UserAdd',
      component: UserAddPage
    },
    {
      path: '/admin/user/:id(\\d+)/edit',
      name: 'UserEdit',
      component: UserEditPage
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'notFound',
      component: NotFound
    },
    {
      path: '/admin/user/match',
      name: 'Match',
      component: MatchPage
      
    },
    {
      path: '/ThankEmail',
      name: 'ThankEmail',
      component: ThankEmailPage
    }
  ]
})

router.beforeEach(async(to, from, next) => {
  if(to.path === "/"){
    next('/announcement')
  }else if(app.$cookies.get("token") === null && app.$cookies.get("refreshToken") === null){
    if(to.fullPath.includes("/admin/"))next('/login')
    else next()
  }else if(to.path !== '/login' && (app.$cookies.get("token") === null && app.$cookies.get("refreshToken") !== null)){
    app.$cookies.set("token",await getNewToken(app.$cookies.get("refreshToken")),tokenExp)
    next()
  }else{
    next()
  }

})

export default router
