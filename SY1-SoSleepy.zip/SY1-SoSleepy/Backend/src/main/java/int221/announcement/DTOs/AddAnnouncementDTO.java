package int221.announcement.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import java.time.ZonedDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class AddAnnouncementDTO {
    private String announcementTitle;
    private String announcementDescription;
    private ZonedDateTime publishDate;
    private ZonedDateTime closeDate;
    private String announcementDisplay;
    private int categoryId;


//    public void setAnnouncementTitle(String title){
//        if (title.length()>200){
//            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "WRONG REQUEST FORMAT");
//        }else{
//            announcementTitle = title;
//        }
//    }
//
//    public void setAnnouncementDescription(String description){
//        if (description.length()>10000){
//            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "WRONG REQUEST FORMAT");
//        }else{
//            announcementDescription = description;
//        }
//    }


}
