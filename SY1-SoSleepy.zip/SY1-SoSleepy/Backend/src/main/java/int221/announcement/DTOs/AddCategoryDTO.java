package int221.announcement.DTOs;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddCategoryDTO {
    private String categoryName;
}
