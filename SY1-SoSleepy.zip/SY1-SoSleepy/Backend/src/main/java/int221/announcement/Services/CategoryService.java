package int221.announcement.Services;

import int221.announcement.Entities.Category;
import int221.announcement.Exceptions.NotFoundException;
import int221.announcement.Repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    public List<Category> getAll(){
        return categoryRepository.findAll();
    }

    public Category getCategory(int id){
        return categoryRepository.findById(Integer.toString(id)).orElseThrow(
                ()-> new NotFoundException("Category id " + id + " does not exist!")
        );
    }

    public Category addNewCategory(Category category){
        Category newCategory = new Category();
        newCategory.setCategoryName(category.getCategoryName());
       return categoryRepository.saveAndFlush(newCategory);
    }

    public void deleteCategory(int id){
        Category category = categoryRepository.findById(Integer.toString(id)).orElseThrow(
                ()-> new NotFoundException("Category id " + id + " does not exist!")
        );
        categoryRepository.deleteById(Integer.toString(id));
    }
}
