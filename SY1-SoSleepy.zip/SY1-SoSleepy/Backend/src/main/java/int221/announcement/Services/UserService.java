package int221.announcement.Services;


import int221.announcement.Config.JwtTokenUtil;
import int221.announcement.DTOs.*;
import int221.announcement.Entities.Announcement;
import int221.announcement.Entities.User;
import int221.announcement.Exceptions.NotFoundException;
import int221.announcement.Exceptions.UnauthorizedException;
import int221.announcement.Repositories.AnnouncementRepository;
import int221.announcement.Repositories.UserRepository;
import int221.announcement.Utils.ListMapper;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Service
public class UserService {
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AnnouncementRepository announcementRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ListMapper listMapper;

    private Argon2PasswordEncoder argon2PasswordEncoder = new Argon2PasswordEncoder(16,32,1,4096,3);


    public List<UserResponse> getAll() {
        Sort sort = Sort.by("role","username");
        return listMapper.mapList(userRepository.findAll(sort), UserResponse.class,modelMapper);
    }

    @Transactional
    public ReturnUserDTO addNewUser(User user){
        User newUser = new User();
        newUser.setUsername(user.getUsername().trim());
        newUser.setPassword(argon2PasswordEncoder.encode(user.getPassword().trim()));
        newUser.setName(user.getName().trim());
        newUser.setEmail(user.getEmail().trim());
        newUser.setRole(user.getRole());
        User saveUser = userRepository.saveAndFlush(newUser);
        entityManager.refresh(saveUser);
        return modelMapper.map(saveUser,ReturnUserDTO .class);
    }
    public ReturnUserDTO getById(int id){
        return modelMapper.map(userRepository.findById(Integer.toString(id)).orElseThrow(
                ()-> new NotFoundException("User id " + id + " does not exist!")
        ),ReturnUserDTO .class);
    }
    public User getUserByUsername(String username){
        User user = userRepository.findUserByUsername(username);
        if (user == null) throw new UnauthorizedException("Username is not exist!!");
        return user;
    }
    @Transactional
    public User updateUserById(int id, UserDTO newUserData){
            User updatedUser = userRepository.findById(Integer.toString(id))
                    .orElseThrow(() -> new NotFoundException("User id " + id + " does not exist! "));
            if (updatedUser.getUsername().trim() == newUserData.getUsername().trim() && updatedUser.getName().trim() == newUserData.getEmail().trim() &&
                    updatedUser.getEmail().trim() == newUserData.getUsername().trim() && updatedUser.getRole() == newUserData.getRole()){
                return updatedUser;
            }
            updatedUser.setUsername(newUserData.getUsername().trim());
            updatedUser.setName(newUserData.getName().trim());
            updatedUser.setEmail(newUserData.getEmail().trim());
            updatedUser.setRole(newUserData.getRole());
            User saveUser = userRepository.saveAndFlush(updatedUser);
            entityManager.refresh(saveUser);
            return saveUser;

    }

    public void deleteById(int id, User admin){
        User user = userRepository.findById(Integer.toString(id))
                .orElseThrow(() -> new NotFoundException("User id" + id + " does not exist! "));
        System.out.println(user);
        List<Announcement> announcements = announcementRepository.findAllByUser(user);
        announcements.stream().forEach(a-> {
            a.setUser(admin);
            announcementRepository.saveAndFlush(a);
        });
        userRepository.delete(user);
    }

    public boolean checkMatch(UserMatchDTO userMatchDTO ) {
        User user = userRepository.findUserByUsername(userMatchDTO.getUsername());
        if (user == null) {
            throw new NotFoundException("User with username " + userMatchDTO.getUsername() + " not found.");
        }else if(argon2PasswordEncoder.matches(userMatchDTO.getPassword(),user.getPassword())){
            return  true;
        }else{
            throw new UnauthorizedException("Password is not match");
        }
    }

    public boolean auth(String username, String password ) {
        User user = userRepository.findUserByUsername(username);
        if (user == null) {
            throw new NotFoundException("User with username " + username + " not found.");
        }else if(argon2PasswordEncoder.matches(password,user.getPassword())){
            return  true;
        }else{
            throw new UnauthorizedException("Password is not match");
        }
    }
    public UserDetailsService userDetailsService() {
        return new UserDetailsService() {
            @Override
            public UserDetails loadUserByUsername(String username) throws NotFoundException {
                int221.announcement.Entities.User user = userRepository.findUserByUsername(username);
                if (user == null) throw new NotFoundException("User with username " + username + " not found.");
                return new org.springframework.security.core.userdetails.User(user.getUsername(),user.getPassword(),new ArrayList<>());
            }
        };
    }

    public String getEmailByUsername(String username){
        User user = userRepository.findUserByUsername(username);
        return user.getEmail();
    }
    public String getRoleByUsername(String username){
        User user = userRepository.findUserByUsername(username);
        if (user == null) throw new NotFoundException("User with username " + username + " not found.");
        return user.getRole().toString();
    }
    public User validateToken(String token){
        String username = null;
        String authToken = null;
        if (token != null && token.startsWith("Bearer ")) {
            authToken = token.replace("Bearer ", "");
            if (!jwtTokenUtil.isTokenExpired(authToken)) {
                username = jwtTokenUtil.getUsernameFromToken(authToken);
                return getUserByUsername(username);
            }
        }
        throw new RuntimeException("User not found");
    }
}
