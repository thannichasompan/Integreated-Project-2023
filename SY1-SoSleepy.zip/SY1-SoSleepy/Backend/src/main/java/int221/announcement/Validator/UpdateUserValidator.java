package int221.announcement.Validator;

import int221.announcement.Annotation.UpdateUserConstraint;
import int221.announcement.DTOs.UserDTO;
import int221.announcement.Exceptions.ErrorResponse;
import int221.announcement.Repositories.UserRepository;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.constraintvalidation.SupportedValidationTarget;
import jakarta.validation.constraintvalidation.ValidationTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.util.Objects;


@SupportedValidationTarget(ValidationTarget.PARAMETERS)
public class UpdateUserValidator implements ConstraintValidator<UpdateUserConstraint, Object[]> {

    @Override
    public void initialize(UpdateUserConstraint constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Autowired
    private UserRepository userRepository;
    @Override
    public boolean isValid(Object objects[], ConstraintValidatorContext context) {
        Integer id = null;
        UserDTO user = null;
        if(objects == null) return false;
        if (objects[0] instanceof Integer)id = (Integer) objects[0];
        if(!userRepository.existsById(id))return true;
        if (objects[0] instanceof UserDTO) user = (UserDTO) objects[0];
        if (objects[1] instanceof UserDTO) user = (UserDTO) objects[1];
        if (userRepository.existsByUsernameAndIdNot(user.getUsername(),id)){
            addValidationError(context ,"Username is already in use");
        }
        if (userRepository.existsByNameAndIdNot(user.getName(),id)){
            addValidationError(context ,"Name is already in use");
        }
        if (userRepository.existsByEmailAndIdNot(user.getEmail(),id)){
            addValidationError(context ,"Email is already in use");
        }
        //logic
        return (!userRepository.existsByUsernameAndIdNot(user.getUsername(),id) && !userRepository.existsByNameAndIdNot(user.getName(),id) && !userRepository.existsByEmailAndIdNot(user.getEmail(),id));
    }
    private void addValidationError(ConstraintValidatorContext context,String err){
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(err).addConstraintViolation();
    }
}
