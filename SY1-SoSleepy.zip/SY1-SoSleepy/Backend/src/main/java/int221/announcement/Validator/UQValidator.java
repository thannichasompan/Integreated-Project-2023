package int221.announcement.Validator;

import int221.announcement.Annotation.UniqueConstraint;
import int221.announcement.Repositories.UserRepository;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Objects;

public class UQValidator implements ConstraintValidator<UniqueConstraint,String> {
    private String data;
    @Autowired
    private UserRepository userRepository;
    @Override
    public void initialize(UniqueConstraint constraintAnnotation) {
        data = constraintAnnotation.uniqueData();
    }

    @Override
    public boolean isValid(String field, ConstraintValidatorContext constraintValidatorContext) {
        if(Objects.equals(data, "username")){
            return !userRepository.existsByUsername(field);
        }else if(Objects.equals(data, "name")){
            return !userRepository.existsByName(field);
        }else if (Objects.equals(data, "email")){
            return !userRepository.existsByEmail(field);
        }else return false;
    }
}
