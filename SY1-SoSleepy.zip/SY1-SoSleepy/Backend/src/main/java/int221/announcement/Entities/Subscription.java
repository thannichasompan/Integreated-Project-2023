package int221.announcement.Entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.ZonedDateTime;

@Getter
@Setter
@Entity
@Table(name = "subscription")
@AllArgsConstructor
@NoArgsConstructor
public class Subscription {
    @EmbeddedId
    SubscribeKey id;

    @ManyToOne
    @MapsId("categoryId")
    @JoinColumn(name = "categoryId")
    private Category category;

    @Column(name = "createdOn", insertable = false, updatable = false)
    private ZonedDateTime createdOn;

    @Column(name = "updatedOn", insertable = false, updatable = false)
    private ZonedDateTime updatedOn;


}
