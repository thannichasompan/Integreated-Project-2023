package int221.announcement.Controllers;

import int221.announcement.DTOs.AddCategoryDTO;
import int221.announcement.Entities.Category;
import int221.announcement.Services.CategoryService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = {"http://localhost:5173/","https://intproj22.sit.kmutt.ac.th/"})
@RequestMapping("/api/categories")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    @Autowired
    private ModelMapper modelMapper;

    @GetMapping("")
    public List<Category> getAllCategory(){
        return categoryService.getAll();
    }
    @GetMapping("/{id}")
    public Category getCategoryById(@PathVariable int id){
        return  categoryService.getCategory(id);
    }
    @PostMapping("")
    public Category addNewCategory(@RequestBody AddCategoryDTO newCategory){
        Category category =  modelMapper.map(newCategory,Category.class);
        return categoryService.addNewCategory(category);
    }

    @DeleteMapping("/{id}")
    public void deleteCategory(@PathVariable int id){
        categoryService.deleteCategory(id);
    }
}
