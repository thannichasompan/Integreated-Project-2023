package int221.announcement.Repositories;

import int221.announcement.Entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,String> {
    User findUserByUsername(String username);

    User findUserByName(String name);

    User findUserByEmail(String name);

    Boolean existsByName(String name);

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);

    Boolean existsByUsernameAndIdNot(String username, int id);

    Boolean existsByNameAndIdNot(String name, int id);

    Boolean existsByEmailAndIdNot(String email, int id);

    Boolean existsById(int id);

}