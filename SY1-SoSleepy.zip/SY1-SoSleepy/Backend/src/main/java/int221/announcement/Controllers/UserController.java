package int221.announcement.Controllers;

import int221.announcement.Annotation.UpdateUserConstraint;
import int221.announcement.DTOs.*;
import int221.announcement.Entities.User;
import int221.announcement.Exceptions.ErrorResponse;
import int221.announcement.Exceptions.ForbiddenException;
import int221.announcement.Services.UserService;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import java.util.List;
import java.util.Set;

@Validated
@RestController
@CrossOrigin(origins = {"http://localhost:5173/","https://intproj22.sit.kmutt.ac.th/","http://127.0.0.1:5173/"})
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private ModelMapper modelMapper;

    @GetMapping("")
    public List<UserResponse> getAll(){
        return userService.getAll();
    }

    @PostMapping("")
    public ReturnUserDTO addNewUser(@Valid @RequestBody AddUserDTO addUserDTO){
        User user = modelMapper.map(addUserDTO , User.class);
        return userService.addNewUser(user);
    }

    @GetMapping("/{id}")
    public ReturnUserDTO getUserById(@PathVariable int id){
        return  userService.getById(id);
    }

    @PutMapping("/{id}")
    @UpdateUserConstraint
    public User upDateUserById(@PathVariable int id ,@Valid @RequestBody UserDTO userDTO){
        return  userService.updateUserById(id, userDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteUserById(@RequestHeader("Authorization") String token,@PathVariable int id){
        User admin = userService.validateToken(token);
        if (admin.getId() == id){
            throw new ForbiddenException("ACCESS DENIED!!!");
        }else{
            userService.deleteById(id,admin);
        }
    }

    @PostMapping("/match")
    public boolean checkMatch(@RequestBody UserMatchDTO userMatchDTO){
        return userService.checkMatch(userMatchDTO);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResponse> handleAllRuntime(MethodArgumentNotValidException exception, WebRequest request) {
        ErrorResponse er = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "User is not valid",
                request.getDescription(false).substring(4)
        );
        exception.getBindingResult().getAllErrors().forEach((err) -> {
            er.addValidationError(((FieldError) err).getField() , err.getDefaultMessage());
        });
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(er);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResponse> handleAllRuntime(ConstraintViolationException exception, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse( HttpStatus.BAD_REQUEST.value(),"User is not valid",request.getDescription(false).substring(4) );
        Set<ConstraintViolation<?>> constraintViolation = exception.getConstraintViolations();
        constraintViolation.forEach(violation ->{
                String[] substring = violation.getMessage().split(" ");
                String fieldName = substring[0].toLowerCase();
                String errorMessage = "does not unique";
                errorResponse.addValidationError(fieldName, errorMessage);
});
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }
}
