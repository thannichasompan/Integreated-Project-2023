package int221.announcement.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class SubscribeKey implements Serializable {
    @Column(name = "email")
    private String email;
    @Column(name = "categoryId")
    private Integer categoryId;
}
