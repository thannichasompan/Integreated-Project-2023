package int221.announcement.Exceptions;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.Set;

@RestControllerAdvice
public class GlobalExceptionHandler {
//    @ExceptionHandler(NotFoundException.class)
//    public ResponseEntity<String> handleNotFoundException(NotFoundException ex) {
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
//    }
    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorResponse> handleAllRuntime(NotFoundException exception, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse( HttpStatus.NOT_FOUND.value(),exception.getMessage() ,request.getDescription(false).substring(4) );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }
    @ExceptionHandler(ForbiddenException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResponseEntity<ErrorResponse> handleAllRuntime(ForbiddenException exception, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse( HttpStatus.FORBIDDEN.value(),exception.getMessage() ,request.getDescription(false).substring(4) );
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(errorResponse);
    }
}
