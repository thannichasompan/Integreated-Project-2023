package int221.announcement.Repositories;

import int221.announcement.Entities.Announcement;
import int221.announcement.Entities.Category;
import int221.announcement.Entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.LongSummaryStatistics;

public interface AnnouncementRepository extends JpaRepository<Announcement,String> {
    // SPRINT 3
    Announcement findByIdAndUser(Integer id,User user);
    List<Announcement> findAllByUser(User user);
    List<Announcement> findAllByUser(User user,Sort sort);
    Page<Announcement> findAllByUser(User user, Pageable pageable);

    Page<Announcement> findAllByUserAndCategory(User user,Category category,Pageable pageable);
    @Query("SELECT e FROM Announcement e WHERE e.category = :category")
    Page<Announcement> findAllByCategory(Category category, Pageable pageable);
    //PBI8-9
    @Query("SELECT e FROM Announcement e WHERE e.announcementDisplay = 'Y' AND (e.publishDate is null or e.publishDate <= :now) AND (e.closeDate is null or e.closeDate > :now) ORDER BY e.id DESC")
    List<Announcement> findAnnouncementActive(ZonedDateTime now);

    @Query("SELECT e FROM Announcement e WHERE e.announcementDisplay = 'Y' AND e.closeDate <= :now ORDER BY e.id DESC")
    List<Announcement> findAnnouncementClosed(ZonedDateTime now);

    @Query("SELECT e FROM Announcement e WHERE e.category = :category ORDER BY e.id DESC")
    List<Announcement> findByCategory(Category category);

    //PBI10
    @Query("SELECT e FROM Announcement e WHERE e.announcementDisplay = 'Y' AND (e.publishDate is null or e.publishDate <= :now) AND (e.closeDate is null or e.closeDate > :now) ORDER BY e.id DESC")
    Page<Announcement> findAllActivePage(ZonedDateTime now, Pageable pageable);

    @Query("SELECT e FROM Announcement e WHERE e.announcementDisplay = 'Y' AND e.closeDate <= :now ORDER BY e.id DESC")
    Page<Announcement> findAllClosePage(ZonedDateTime now,Pageable pageable);
    @Query("SELECT e FROM Announcement e WHERE e.announcementDisplay = 'Y' AND e.category = :category AND (e.publishDate is null or e.publishDate <= :now) AND (e.closeDate is null or e.closeDate > :now) ORDER BY e.id DESC")

    Page<Announcement> findByCategoryActive(Category category,ZonedDateTime now,Pageable pageable);

    @Query("SELECT e FROM Announcement e WHERE e.announcementDisplay = 'Y' AND e.category = :category AND e.closeDate <= :now ORDER BY e.id DESC")
    Page<Announcement> findByCategoryClose(Category category, ZonedDateTime now,Pageable pageable);

    @Modifying
    @Query("UPDATE Announcement e SET e.user=:newUser WHERE e.user=:oldUser")
    void setNewUserToAnnouncement(User oldUser,User newUser);

}
