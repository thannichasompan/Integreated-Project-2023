package int221.announcement.Controllers;

import int221.announcement.Config.JwtTokenUtil;
import int221.announcement.DTOs.JwtRequest;
import int221.announcement.DTOs.JwtResponse;
import int221.announcement.DTOs.tokenResponse;
import int221.announcement.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin(origins = {"http://localhost:5173/","https://intproj22.sit.kmutt.ac.th/"})
@RequestMapping("/api/token")
public class JwtController {
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserService userService;

    @GetMapping("")
    public ResponseEntity<?> createNewToken(@RequestHeader("Authorization") String refreshToken) throws Exception,RuntimeException {
        String username = null;
        String authToken = null;
        if (refreshToken != null && refreshToken.startsWith("Bearer ")) {
            authToken = refreshToken.replace("Bearer ", "");
            if (!jwtTokenUtil.isTokenExpired(authToken)) {
            username = jwtTokenUtil.getUsernameFromToken(authToken);
            String email = userService.getEmailByUsername(username);
            String role = userService.getRoleByUsername(username);
            final String token = jwtTokenUtil.generateToken(username,email,role);
            return ResponseEntity.ok(new tokenResponse(token));
            }
        }
        throw new RuntimeException("IDK");
    }

    @PostMapping("")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest jwtRequest) throws Exception {
        //Auth
        authenticate(jwtRequest.getUsername(), jwtRequest.getPassword());
        //Find user by username
        final UserDetails userDetails = userService.userDetailsService().loadUserByUsername(jwtRequest.getUsername());
        String role = userService.getRoleByUsername(jwtRequest.getUsername());
        String email = userService.getEmailByUsername(jwtRequest.getUsername());
        //Generate token & refreshToken
        final String token = jwtTokenUtil.generateToken(userDetails.getUsername(),email,role);
        final String refreshToken = jwtTokenUtil.generateRefreshToken(userDetails.getUsername());

        return ResponseEntity.ok(new JwtResponse(token, refreshToken));

    }
    private void authenticate(String username, String password) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (DisabledException e) {
            throw new Exception("USER_DISABLED", e);
        } catch (BadCredentialsException e) {
            throw new Exception("INVALID_CREDENTIALS", e);
        }
    }
}
