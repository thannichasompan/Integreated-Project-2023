package int221.announcement.DTOs;
import int221.announcement.Entities.User;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
    @NotBlank
    @Size(min = 1,max = 45)
    private String username;
    @NotBlank
    @Size(min = 1,max = 100)
    private String name;
    @NotBlank
    @Size(min = 1,max = 150)
    @Email(regexp = "^[^@]+@[^@]+\\.[^.]{1,3}$",message = "Email should be valid")
    private String email;
    @NotNull
    private User.UserRole role;

}
