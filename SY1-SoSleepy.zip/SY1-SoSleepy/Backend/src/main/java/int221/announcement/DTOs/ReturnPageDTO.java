package int221.announcement.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnore;
import int221.announcement.Entities.Category;
import int221.announcement.Entities.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.ZonedDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReturnPageDTO {
    private Integer id;
    private String announcementTitle;
    private ZonedDateTime publishDate;
    private ZonedDateTime closeDate;
    private String announcementDisplay;

    @JsonIgnore
    private Category category;

    public String getAnnouncementCategory(){
        return category.getCategoryName();
    }

    @JsonIgnore
    private User user;

    public String getAnnouncementOwner(){return user.getUsername();}
}
