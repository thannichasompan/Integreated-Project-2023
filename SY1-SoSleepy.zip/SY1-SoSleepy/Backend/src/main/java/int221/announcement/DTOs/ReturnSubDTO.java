package int221.announcement.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnore;
import int221.announcement.Entities.SubscribeKey;
import lombok.Getter;
import lombok.Setter;

import java.time.ZonedDateTime;

@Getter
@Setter
public class ReturnSubDTO {
    @JsonIgnore
    private SubscribeKey id;

    public String getEmail(){
        return id.getEmail();
    }
    private String categoryName;
    private ZonedDateTime createdOn;
    private ZonedDateTime updatedOn;
}
