package int221.announcement.Services;

import int221.announcement.DTOs.*;
import int221.announcement.Entities.Announcement;
import int221.announcement.Entities.Category;
import int221.announcement.Entities.User;
import int221.announcement.Exceptions.ForbiddenException;
import int221.announcement.Exceptions.NotFoundException;
import int221.announcement.Repositories.AnnouncementRepository;
import int221.announcement.Repositories.CategoryRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.Clock;
import java.time.ZonedDateTime;
import java.util.List;

@Service
public class AnnouncementService {
    @Autowired
    private AnnouncementRepository announcementRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ModelMapper modelMapper;

    // SPRINT 1
    public List<Announcement> getAll(String mode) {
        Sort sort = Sort.by(Sort.Direction.DESC, "id");
        if (mode.equals("admin")) {
            return announcementRepository.findAll(sort);
        } else if (mode.equals("active")) {
            return announcementRepository.findAnnouncementActive(ZonedDateTime.now(Clock.systemUTC()));
        } else if (mode.equals("close")){
            return announcementRepository.findAnnouncementClosed(ZonedDateTime.now(Clock.systemUTC()));
        }else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "WRONG REQUEST FORMAT");
        }

    }
    public List<Announcement> getAllByUser(String mode,User user) {
        Sort sort = Sort.by(Sort.Direction.DESC, "id");
        if (mode.equals("admin")) {
            if (user.getRole().toString().equals("admin")){
                return announcementRepository.findAll(sort);
            }else{
                return announcementRepository.findAllByUser(user,sort);
            }
        } else if (mode.equals("active")) {
            return announcementRepository.findAnnouncementActive(ZonedDateTime.now(Clock.systemUTC()));
        } else if (mode.equals("close")){
            return announcementRepository.findAnnouncementClosed(ZonedDateTime.now(Clock.systemUTC()));
        }else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "WRONG REQUEST FORMAT");
        }

    }

    public Announcement getById(int id , boolean count){
        Announcement announcement = announcementRepository.findById(Integer.toString(id)).orElseThrow(
                ()-> new NotFoundException("Announcement id " + id + " does not exist!")
        );
        if(count){
            announcement.setViewCount(announcement.getViewCount()+1);
            return announcementRepository.saveAndFlush(announcement);
        }
        return announcement;

    }
    public Announcement getByIdAndUser(int id , boolean count,User user){
        Announcement announcement = announcementRepository.findById(Integer.toString(id)).orElseThrow(
                ()-> new NotFoundException("Announcement id " + id + " does not exist!")
        );
        if (!announcement.getUser().equals(user) && !user.getRole().toString().equals("admin")){
            throw new ForbiddenException("Access Denied!!!");
        }
        if(count){
            announcement.setViewCount(announcement.getViewCount()+1);
            return announcementRepository.saveAndFlush(announcement);
        }
        return announcement;

    }
    // SPRINT 2
    // CREATE-ANNOUNCEMENT
    public ReturnAnnouncement createAnnouncement(Announcement announcement, User user){
        Announcement newAnnouncement = new Announcement();
        newAnnouncement.setAnnouncementTitle(announcement.getAnnouncementTitle());
        newAnnouncement.setAnnouncementDescription(announcement.getAnnouncementDescription());
        newAnnouncement.setPublishDate(announcement.getPublishDate());
        newAnnouncement.setCloseDate(announcement.getCloseDate());
        newAnnouncement.setAnnouncementDisplay(announcement.getAnnouncementDisplay());
        newAnnouncement.setViewCount(0);
        newAnnouncement.setUser(user);
        Category category = categoryRepository.findById(Integer.toString(announcement.getCategory().getId())).orElseThrow(
                ()-> new NotFoundException("Category id " + announcement.getCategory().getId() + " does not exist!")
        );
        newAnnouncement.setCategory(category);
        return modelMapper.map(announcementRepository.saveAndFlush(newAnnouncement),ReturnAnnouncement.class);
    }


    // DELETE-ANNOUNCEMENT
    public void deleteAnnouncementById(int id,User user){
        Announcement announcement = announcementRepository.findById(Integer.toString(id))
                .orElseThrow(() -> new NotFoundException("Announcement id" + id + " does not exist! "));
        if (!announcement.getUser().equals(user) && !user.getRole().toString().equals("admin")){
            throw new ForbiddenException("Access Denied!!!");
        }
        announcementRepository.delete(announcement);
    }

    // UPDATE-ANNOUNCEMENT
    public ReturnAnnouncement upDateAnnouncementById(int id, AddAnnouncementDTO addAnnouncementDTO,User user){
        Announcement upDateAnnouncement = announcementRepository.findById(Integer.toString(id))
                .orElseThrow(() -> new NotFoundException("Announcement id" + id + " does not exist! "));
        if (!upDateAnnouncement.getUser().equals(user) && !user.getRole().toString().equals("admin")){
            throw new ForbiddenException("Access Denied!!!");
        }
        upDateAnnouncement.setAnnouncementTitle(addAnnouncementDTO.getAnnouncementTitle());
        upDateAnnouncement.setAnnouncementDescription(addAnnouncementDTO.getAnnouncementDescription());
        upDateAnnouncement.setPublishDate(addAnnouncementDTO.getPublishDate());
        upDateAnnouncement.setCloseDate(addAnnouncementDTO.getCloseDate());
        upDateAnnouncement.setAnnouncementDisplay(addAnnouncementDTO.getAnnouncementDisplay());

        Category category = categoryRepository.findById(Integer.toString(addAnnouncementDTO.getCategoryId()))
                .orElseThrow(()-> new NotFoundException("Announcement id " + addAnnouncementDTO.getCategoryId() + " does not exist!"));
        upDateAnnouncement.setCategory(category);
        return modelMapper.map(announcementRepository.saveAndFlush(upDateAnnouncement), ReturnAnnouncement.class);
    }

    // SPRINT 3
    // USER-VIEW-ANNOUNCEMENT-PAGE
    public Page<Announcement> getAnnouncementWithPagination(int page, int size){
        return announcementRepository.findAll(PageRequest.of(page, size));
    }
    public Page<Announcement> getAnnouncementPageWithCategoryAndUser(int page, int size, int categoryId, String mode,User user){
            Sort sort = Sort.by(Sort.Direction.DESC, "id");
            Pageable pageAdmin = PageRequest.of(page, size, sort);
        System.out.println(user.getRole().toString());
            if (categoryId == 0){
                if (user.getRole().toString().equals("admin")){
                    return announcementRepository.findAll(pageAdmin);
                }
                return announcementRepository.findAllByUser(user,pageAdmin);
            }else{
                Category category = categoryRepository.findById(Integer.toString(categoryId)).orElseThrow(
                        ()-> new NotFoundException("Category id " + categoryId + " does not exist!")
                );
                if (user.getRole().toString().equals("admin")){
                    return announcementRepository.findAllByCategory(category,pageAdmin);
                }
                return announcementRepository.findAllByUserAndCategory(user,category,pageAdmin);
            }
    }
    public Page<Announcement> getAnnouncementPageWithCategory(int page, int size, int categoryId, String mode){
        Pageable pageable = PageRequest.of(page, size);
        ZonedDateTime now = ZonedDateTime.now(Clock.systemUTC());
        if(mode.equals("admin")){
            Sort sort = Sort.by(Sort.Direction.DESC, "id");
            Pageable pageAdmin = PageRequest.of(page, size, sort);
            if (categoryId == 0){
                return announcementRepository.findAll(pageAdmin);
            }else{
                Category category = categoryRepository.findById(Integer.toString(categoryId)).orElseThrow(
                        ()-> new NotFoundException("Category id " + categoryId + " does not exist!")
                );
                return announcementRepository.findAllByCategory(category,pageAdmin);
            }
        }   else if (mode.equals("active")) {
            if (categoryId == 0){
                return announcementRepository.findAllActivePage(now,pageable);
            }else{
                Category category = categoryRepository.findById(Integer.toString(categoryId)).orElseThrow(
                        ()-> new NotFoundException("Category id " + categoryId + " does not exist!")
                );
                return announcementRepository.findByCategoryActive(category,now,pageable);
            }
        } else if (mode.equals("close")){
            if (categoryId == 0){
                return announcementRepository.findAllClosePage(now,pageable);
            }else{
                Category category = categoryRepository.findById(Integer.toString(categoryId)).orElseThrow(
                        ()-> new NotFoundException("Category id " + categoryId + " does not exist!")
                );
                return announcementRepository.findByCategoryClose(category,now,pageable);
            }
        }else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "WRONG REQUEST FORMAT");
        }
    }
//    // USER-VIEW-ANNOUNCEMENT-BY-CATEGORY
//    public List<Announcement> getAnnouncementWithCategory(int id, Sort sortBy){
//        Sort sort = Sort.by(sortBy);
//        return announcementRepository.findAnnouncementsByCategory_IdContainingIgnoreCase(id, sort);
//
//    }

}
