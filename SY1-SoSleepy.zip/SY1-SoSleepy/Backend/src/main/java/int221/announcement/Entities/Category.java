package int221.announcement.Entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "category")
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "categoryId")
    private int id;

    @Column(name = "categoryName", nullable = false)
    private String categoryName;

    // Announcement
//    @JsonIgnore
//    @OneToMany(mappedBy = "categoryObj")
//    private Set<Announcement> announcements = new LinkedHashSet<>();
}
