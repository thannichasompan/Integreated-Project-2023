package int221.announcement.Config;

import int221.announcement.Entities.User;
import int221.announcement.Exceptions.ForbiddenException;
import int221.announcement.Exceptions.UnauthorizedException;
import int221.announcement.Services.UserService;
import io.jsonwebtoken.*;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {
    @Autowired
    private UserService userService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Value("${jwt.secret}")
    private String secret;

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws IOException, ServletException {
        String header = req.getHeader("Authorization");
        String mode = req.getParameter("mode");
        String url = req.getRequestURI();
        String username = null;
        String authToken = null;
        if (header != null && header.startsWith("Bearer ")) {
            authToken = header.replace("Bearer ", "");
                try {
                    username = jwtTokenUtil.getUsernameFromToken(authToken);
                } catch (IllegalArgumentException e) {
                    logger.error("an error occured during getting username from token", e);
                } catch (ExpiredJwtException e) {
                    logger.warn("the token is expired and not valid anymore", e);
                } catch (SignatureException e) {
                    logger.error("Authentication Failed. Username or Password not valid.");
                }
            } else {
                logger.warn("couldn't find bearer string, will ignore the header");
            }

            if(mode != null && (url.equals("/api/announcements") || url.equals("/api/announcements/pages"))){
                if (mode.equals("admin") && username == null) throw new UnauthorizedException("You didn't have permission!!!");
            } else if (mode == null && (url.equals("/api/announcements") || url.equals("/api/announcements/pages"))) {
                if (username == null) throw new UnauthorizedException("You didn't have permission!!!");
            }
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = userService.userDetailsService().loadUserByUsername(username);
                User user = userService.getUserByUsername(username);
                String type = Jwts.parser().setSigningKey(secret).parseClaimsJws(authToken).getHeader().getType();
                if(mode != null) {
                    if (mode.equals("admin") && !(user.getRole().toString().equals("admin") || user.getRole().toString().equals("announcer"))) throw new UnauthorizedException("You didn't have permission!!!");
                }else{
                    if ((url.equals("/api/announcements") || url.equals("/api/announcements/pages")) && !(user.getRole().toString().equals("admin") || user.getRole().toString().equals("announcer"))) throw new UnauthorizedException("You didn't have permission!!!4");
                }
                if (type.equals("ACCESS")){
                    if (jwtTokenUtil.validateToken(authToken, userDetails)) {
                        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                                userDetails, null, List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().toString().toUpperCase())));
                        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
                        logger.info("authenticated user " + username + ", setting security context");
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                    }
                }
            }
        chain.doFilter(req, res);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        return request.getRequestURI().startsWith("/api/subscribe");
    }
}
