package int221.announcement.DTOs;


import int221.announcement.Annotation.UniqueConstraint;
import int221.announcement.Entities.User;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AddUserDTO {
    @NotBlank
    @UniqueConstraint(uniqueData = "username")
    @Size(min = 1,max = 45)
    private String username;
    @NotBlank
    @Size(min = 8,max = 14)
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%^#&*()_+{}\\[\\]:;<>,.?/~\\\\|-])[\\S]{8,14}$", message = "must be 8-14 characters long, at least 1 of uppercase, lowercase, number and special characters")
    private String password;
    @NotBlank
    @UniqueConstraint(uniqueData = "name")
    @Size(min = 1,max = 100)
    private String name;
    @NotBlank
    @UniqueConstraint(uniqueData = "email")
    @Size(min = 1,max = 150)
    @Email(regexp = "^[^@]+@[^@]+\\.[^.]{1,3}$",message = "Email should be valid")
    private String email;
    @NotNull
    private User.UserRole role;

}
