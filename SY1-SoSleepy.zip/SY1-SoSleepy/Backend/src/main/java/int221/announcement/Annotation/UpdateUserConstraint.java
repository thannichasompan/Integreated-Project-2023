package int221.announcement.Annotation;

import int221.announcement.Validator.UpdateUserValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;



@Constraint(validatedBy = UpdateUserValidator.class)
@Target({ElementType.METHOD, ElementType.CONSTRUCTOR })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface UpdateUserConstraint {
    String field() default "";
    String message() default "User is not valid";

    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
