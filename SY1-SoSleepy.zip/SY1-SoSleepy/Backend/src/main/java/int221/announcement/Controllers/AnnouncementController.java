package int221.announcement.Controllers;

import int221.announcement.Config.JwtTokenUtil;
import int221.announcement.DTOs.*;
import int221.announcement.Entities.Announcement;
import int221.announcement.Entities.User;
import int221.announcement.Exceptions.UnauthorizedException;
import int221.announcement.Services.AnnouncementService;
import int221.announcement.Services.UserService;
import int221.announcement.Utils.ListMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@CrossOrigin(origins = {"http://localhost:5173/", "https://intproj22.sit.kmutt.ac.th/"})
@RequestMapping("/api/announcements")
public class AnnouncementController {

    @Autowired
    private UserService userService;
    @Autowired
    private AnnouncementService announcementService;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ListMapper listMapper;

    @GetMapping("")
    public List<AnnouncementDTO> getAllAnnouncement(@RequestHeader(value = "Authorization", required = false) String token, @RequestParam(defaultValue = "admin")String mode){
        if (token != null){
            User user = userService.validateToken(token);
            return listMapper.mapList(announcementService.getAllByUser(mode,user),AnnouncementDTO.class,modelMapper);
        }
        return listMapper.mapList(announcementService.getAll(mode),AnnouncementDTO.class,modelMapper);
    }
    @GetMapping("/{id}")
    public DetailDTO getAnnouncementById(
            @RequestHeader(value = "Authorization", required = false) String token,
            @PathVariable int id,
            @RequestParam(defaultValue = "false") boolean count
    ){
        if(token != null){
            User user = userService.validateToken(token);
            return modelMapper.map(announcementService.getByIdAndUser(id, count,user),DetailDTO.class);
        }
        return modelMapper.map(announcementService.getById(id, count),DetailDTO.class);
    }

    @GetMapping("/catId/{id}")
    public DetailWithCatId getDetailWithCatId(@PathVariable int id){
        return modelMapper.map(announcementService.getById(id, false),DetailWithCatId.class);
    }

    @PostMapping("")
    public ReturnAnnouncement createAnnouncement(@RequestHeader("Authorization") String token,@RequestBody AddAnnouncementDTO announcementDTO ){
        User user = userService.validateToken(token);
        Announcement announcement = modelMapper.map(announcementDTO, Announcement.class);
        return announcementService.createAnnouncement(announcement,user);
    }

    @DeleteMapping("/{id}")
    public void deleteAnnouncementById(@RequestHeader("Authorization") String token,@PathVariable int id){
        if (token != null) {
            User user = userService.validateToken(token);
            announcementService.deleteAnnouncementById(id,user);
        }
    }

    @PutMapping("/{id}")
    public ReturnAnnouncement upDateAnnouncementById(@RequestHeader("Authorization") String token,@RequestBody AddAnnouncementDTO addAnnouncementDTO, @PathVariable int id){
        if (token != null){
            User user = userService.validateToken(token);
            return announcementService.upDateAnnouncementById(id,addAnnouncementDTO,user);
        }
        throw new UnauthorizedException("No permission!!");
    }


//    @GetMapping("/pages")
//    public PageDTO<ReturnPageDTO> getAnnouncementWithPagination() {
//        Page<Announcement> announcementList = announcementService.getAnnouncementWithPagination(0,5);
//        return listMapper.toPageDTO(announcementList, ReturnPageDTO.class, modelMapper);
//    }
    @GetMapping("/pages")
    public PageDTO getAnnouncementWithPagination(
            @RequestHeader(value = "Authorization", required = false) String token,
            @RequestParam(defaultValue = "admin") String mode,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "0") int category
    ) {
        if (token != null) {
            User user = userService.validateToken(token);
        if(mode.equals("admin") && user != null){
            return listMapper.toPageDTO(announcementService.getAnnouncementPageWithCategoryAndUser(page, size, category, mode,user),ReturnAdminDTO.class,modelMapper);
            }
        }else{
            return listMapper.toPageDTO(announcementService.getAnnouncementPageWithCategory(page, size, category, mode),ReturnPageDTO.class,modelMapper);
        }
       return null;
    }


}
