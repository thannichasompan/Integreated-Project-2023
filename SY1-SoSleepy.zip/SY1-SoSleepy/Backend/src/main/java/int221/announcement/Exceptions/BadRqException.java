package int221.announcement.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class BadRqException extends RuntimeException{
    public BadRqException(String message){
        super(message);
    }
}
