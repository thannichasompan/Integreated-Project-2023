package int221.announcement.Controllers;

import int221.announcement.DTOs.SubscribeDTO;
import int221.announcement.Services.SubscriberService;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;


@RestController
@CrossOrigin(origins = {"http://localhost:5173/","https://intproj22.sit.kmutt.ac.th/"})
@RequestMapping("/api/subscribe")
public class SubscriptionController {
    @Autowired
    private SubscriberService subscriberService;

    @PostMapping("/verify")
    public ResponseEntity sendEmailVerification(@RequestBody SubscribeDTO subscribeDTO) throws MessagingException {
            subscriberService.emailVerification(subscribeDTO);
            return ResponseEntity.ok("Confirmation email was sent!!!");
    }

    @GetMapping("")
    public RedirectView subscribe(@RequestParam String token) {
        subscriberService.subscription(token);
        return new RedirectView("http://localhost:5173/ThankEmail");
    }
}
