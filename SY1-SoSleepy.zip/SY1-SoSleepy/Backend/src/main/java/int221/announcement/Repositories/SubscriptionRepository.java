package int221.announcement.Repositories;


import int221.announcement.Entities.SubscribeKey;
import int221.announcement.Entities.Subscription;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscriptionRepository extends JpaRepository<Subscription, SubscribeKey> {
    boolean existsById(SubscribeKey subscribeKey);
}
