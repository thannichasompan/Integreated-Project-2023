package int221.announcement.Config;

import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Component
public class JwtTokenUtil implements Serializable {
    @Value("#{${jwt.tokenExp}}")
    private long ExpireInHrs;

    @Value("#{${jwt.refreshTokenExp}}")
    private long refreshTokenExpInHrs;

    @Value("${jwt.secret}")
    private String secret;

    public String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    public Claims getBodyFromToken(String token){
        return Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token)
                .getBody();
    }
    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token)
                .getBody();
    }

    public Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }
//Generate Token
    public String generateToken(String username,String email,String role) {
        Map<String, Object> claims = new HashMap<>();
        return doGenerateToken(username,email,role,claims);
    }

    private String doGenerateToken(String subject,String email,String role, Map<String, Object> claims) {
        Header header = Jwts.header();
        header.setType("ACCESS");
        return Jwts.builder()
                .setHeader((Map<String,Object>) header)
                .setClaims(claims)
                .claim("role",role)
                .claim("email", email)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + ExpireInHrs))
                .signWith(SignatureAlgorithm.HS256, secret)
                .compact();
    }

    //Generate refreshToken
    public String generateRefreshToken(String username) {
        Map<String, Object> claims = new HashMap<>();
        return doGenerateRefreshToken(username,claims);
    }

    private String doGenerateRefreshToken(String subject, Map<String, Object> claims) {
        Header header = Jwts.header();
        header.setType("REFRESH");
        return Jwts.builder()
                .setHeader((Map<String,Object>) header)
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + refreshTokenExpInHrs))
                .signWith(SignatureAlgorithm.HS256, secret)
                .compact();
    }
//Verification
public String generateVerifyToken(String email, Integer categoryId) {
    Map<String, Object> claims = new HashMap<>();
    return doGenerateVerifyToken(email,claims,categoryId);
}

    private String doGenerateVerifyToken(String subject, Map<String, Object> claims, Integer categoryId) {
        Header header = Jwts.header();
        header.setType("VERIFY");
        return Jwts.builder()
                .setHeader((Map<String,Object>) header)
                .setClaims(claims)
                .claim("category", categoryId)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
//        1000*60*15
                .setExpiration(new Date(System.currentTimeMillis() + refreshTokenExpInHrs))
                .signWith(SignatureAlgorithm.HS256, secret)
                .compact();
    }
    public Boolean validateToken(String token, UserDetails userDetails) {
        final String username = getUsernameFromToken(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }
}
