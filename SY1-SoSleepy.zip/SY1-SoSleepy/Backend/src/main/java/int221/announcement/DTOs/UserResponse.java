package int221.announcement.DTOs;

import int221.announcement.Entities.User;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.ZonedDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {

    private Integer id;
    private String username;
    private String name;
    private String email;
    private User.UserRole role;
    private ZonedDateTime createdOn;
    private ZonedDateTime updatedOn;

}
