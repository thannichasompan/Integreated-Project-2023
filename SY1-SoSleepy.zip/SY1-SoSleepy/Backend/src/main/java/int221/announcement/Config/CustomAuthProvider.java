package int221.announcement.Config;

import int221.announcement.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import java.util.ArrayList;

@Component
public class CustomAuthProvider implements AuthenticationProvider {
    @Autowired
    private UserService userService;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        final String username = authentication.getPrincipal().toString();
        final String password = authentication.getCredentials().toString();
        if (userService.auth(username,password)) {
            return new UsernamePasswordAuthenticationToken(username,password,new ArrayList<>());
        }else {
            return null;
        }
    }

    @Override
    public boolean supports(Class< ? > authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }



}
